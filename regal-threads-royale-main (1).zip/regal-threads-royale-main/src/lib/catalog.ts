import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type ProductImage = { id: string; url: string; alt: string | null; sort_order: number };
export type Variant = { id: string; size: string; color: string; stock: number; sku: string | null };

export type Product = {
  id: string;
  slug: string;
  name: string;
  sku: string;
  description: string | null;
  gender: string;
  category_id: string | null;
  collection_id: string | null;
  price: number;
  mrp: number;
  fabric: string | null;
  occasion: string | null;
  care: string | null;
  colors: string[];
  sizes: string[];
  rating: number;
  review_count: number;
  is_published: boolean;
  is_featured: boolean;
  is_bestseller: boolean;
  is_new_arrival: boolean;
  created_at: string;
  product_images: ProductImage[];
  categories?: { name: string; slug: string } | null;
  collections?: { name: string; slug: string } | null;
};

export type Category = {
  id: string;
  slug: string;
  name: string;
  gender: string;
  image_url: string | null;
};
export type Collection = {
  id: string;
  slug: string;
  name: string;
  tagline: string | null;
  image_url: string | null;
};
export type Banner = {
  id: string;
  placement: string;
  title: string;
  subtitle: string | null;
  image_url: string | null;
  cta_label: string | null;
  cta_href: string | null;
  is_active: boolean;
  sort_order: number;
};

const PRODUCT_SELECT =
  "*, product_images(id,url,alt,sort_order), categories(name,slug), collections(name,slug)";

export type ProductFilters = {
  gender?: string | undefined;
  category?: string | undefined;
  collection?: string | undefined;
  search?: string | undefined;
  sizes?: string[] | undefined;
  colors?: string[] | undefined;
  occasion?: string | undefined;
  fabric?: string | undefined;
  minPrice?: number | undefined;
  maxPrice?: number | undefined;
  inStockOnly?: boolean | undefined;
  minRating?: number | undefined;
  minDiscount?: number | undefined;
  sort?: string | undefined;
  flag?: "new" | "bestseller" | "featured" | undefined;
  limit?: number | undefined;
};

export function productsQuery(filters: ProductFilters = {}) {
  return queryOptions({
    queryKey: ["products", filters],
    queryFn: async (): Promise<Product[]> => {
      let q = supabase.from("products").select(PRODUCT_SELECT).eq("is_published", true);
      if (filters.gender) q = q.eq("gender", filters.gender);
      if (filters.search) q = q.ilike("name", `%${filters.search}%`);
      if (filters.occasion) q = q.eq("occasion", filters.occasion);
      if (filters.fabric) q = q.eq("fabric", filters.fabric);
      if (filters.minPrice !== undefined) q = q.gte("price", filters.minPrice);
      if (filters.maxPrice !== undefined) q = q.lte("price", filters.maxPrice);
      if (filters.minRating) q = q.gte("rating", filters.minRating);
      if (filters.flag === "new") q = q.eq("is_new_arrival", true);
      if (filters.flag === "bestseller") q = q.eq("is_bestseller", true);
      if (filters.flag === "featured") q = q.eq("is_featured", true);

      switch (filters.sort) {
        case "newest":
          q = q.order("created_at", { ascending: false });
          break;
        case "price-asc":
          q = q.order("price", { ascending: true });
          break;
        case "price-desc":
          q = q.order("price", { ascending: false });
          break;
        case "rating":
          q = q.order("rating", { ascending: false });
          break;
        case "popular":
          q = q.order("review_count", { ascending: false });
          break;
        default:
          q = q.order("is_featured", { ascending: false }).order("rating", { ascending: false });
      }
      if (filters.limit) q = q.limit(filters.limit);

      const { data, error } = await q;
      if (error) throw error;
      let rows = (data ?? []) as unknown as Product[];

      if (filters.category) rows = rows.filter((p) => p.categories?.slug === filters.category);
      if (filters.collection) rows = rows.filter((p) => p.collections?.slug === filters.collection);
      if (filters.sizes?.length)
        rows = rows.filter((p) => filters.sizes!.some((s) => p.sizes.includes(s)));
      if (filters.colors?.length)
        rows = rows.filter((p) => filters.colors!.some((c) => p.colors.includes(c)));
      if (filters.minDiscount)
        rows = rows.filter(
          (p) => ((Number(p.mrp) - Number(p.price)) / Number(p.mrp)) * 100 >= filters.minDiscount!,
        );
      if (filters.sort === "discount")
        rows = [...rows].sort(
          (a, b) =>
            (Number(b.mrp) - Number(b.price)) / Number(b.mrp) -
            (Number(a.mrp) - Number(a.price)) / Number(a.mrp),
        );
      return rows;
    },
  });
}

export function productQuery(slug: string) {
  return queryOptions({
    queryKey: ["product", slug],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select(PRODUCT_SELECT)
        .eq("slug", slug)
        .maybeSingle();
      if (error) throw error;
      return (data ?? null) as unknown as Product | null;
    },
  });
}

export function variantsQuery(productId: string | undefined) {
  return queryOptions({
    queryKey: ["variants", productId],
    enabled: !!productId,
    queryFn: async (): Promise<Variant[]> => {
      const { data, error } = await supabase
        .from("product_variants")
        .select("id,size,color,stock,sku")
        .eq("product_id", productId!);
      if (error) throw error;
      return (data ?? []) as Variant[];
    },
  });
}

export function reviewsQuery(productId?: string) {
  return queryOptions({
    queryKey: ["reviews", productId ?? "all"],
    queryFn: async () => {
      let q = supabase
        .from("reviews")
        .select("id,product_id,author_name,rating,body,is_verified,created_at,is_approved")
        .eq("is_approved", true)
        .order("created_at", { ascending: false });
      if (productId) q = q.eq("product_id", productId);
      else q = q.limit(6);
      const { data, error } = await q;
      if (error) throw error;
      return data ?? [];
    },
  });
}

export const categoriesQuery = () =>
  queryOptions({
    queryKey: ["categories"],
    queryFn: async (): Promise<Category[]> => {
      const { data, error } = await supabase
        .from("categories")
        .select("id,slug,name,gender,image_url")
        .order("sort_order");
      if (error) throw error;
      return (data ?? []) as Category[];
    },
  });

export const collectionsQuery = () =>
  queryOptions({
    queryKey: ["collections"],
    queryFn: async (): Promise<Collection[]> => {
      const { data, error } = await supabase
        .from("collections")
        .select("id,slug,name,tagline,image_url")
        .order("sort_order");
      if (error) throw error;
      return (data ?? []) as Collection[];
    },
  });

export const bannersQuery = (placement?: string) =>
  queryOptions({
    queryKey: ["banners", placement ?? "all"],
    queryFn: async (): Promise<Banner[]> => {
      let q = supabase.from("banners").select("*").eq("is_active", true).order("sort_order");
      if (placement) q = q.eq("placement", placement);
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as Banner[];
    },
  });

export function primaryImage(p: Pick<Product, "product_images">): string {
  const imgs = [...(p.product_images ?? [])].sort((a, b) => a.sort_order - b.sort_order);
  return imgs[0]?.url ?? "/images/hero.jpg";
}

export function secondaryImage(p: Pick<Product, "product_images">): string | null {
  const imgs = [...(p.product_images ?? [])].sort((a, b) => a.sort_order - b.sort_order);
  return imgs[1]?.url ?? null;
}
