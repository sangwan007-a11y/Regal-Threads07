import { SITE } from "@/config/site";
import { inr } from "./format";

export type WhatsAppLine = {
  name: string;
  sku?: string | null;
  size?: string | null;
  color?: string | null;
  quantity?: number;
  price?: number | string;
};

function buildMessage(lines: WhatsAppLine[], note?: string): string {
  const header = `Hello ${SITE.name}, I would like to order:`;
  const body = lines
    .map((l) =>
      [
        `Product: ${l.name}`,
        l.sku ? `SKU: ${l.sku}` : null,
        l.size ? `Size: ${l.size}` : null,
        l.color ? `Color: ${l.color}` : null,
        l.quantity ? `Quantity: ${l.quantity}` : null,
        l.price !== undefined ? `Price: ${inr(l.price)}` : null,
      ]
        .filter(Boolean)
        .join("\n"),
    )
    .join("\n\n");
  return [header, "", body, note ? `\n${note}` : ""].join("\n").trim();
}

export function whatsappUrl(lines: WhatsAppLine[], note?: string): string {
  return `https://wa.me/${SITE.whatsappNumber}?text=${encodeURIComponent(buildMessage(lines, note))}`;
}

export function whatsappEnquiryUrl(text: string): string {
  return `https://wa.me/${SITE.whatsappNumber}?text=${encodeURIComponent(text)}`;
}
