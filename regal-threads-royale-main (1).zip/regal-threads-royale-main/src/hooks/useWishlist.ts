import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./useAuth";
import type { Product } from "@/lib/catalog";

export type WishlistRow = { id: string; product_id: string; products: Product };

export function useWishlist() {
  const { user } = useAuth();
  const qc = useQueryClient();

  const query = useQuery({
    queryKey: ["wishlist", user?.id],
    enabled: !!user,
    queryFn: async (): Promise<WishlistRow[]> => {
      const { data, error } = await supabase
        .from("wishlist_items")
        .select("id,product_id, products(*, product_images(id,url,alt,sort_order))")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as WishlistRow[];
    },
  });

  const ids = new Set((query.data ?? []).map((r) => r.product_id));

  const toggle = useMutation({
    mutationFn: async (productId: string) => {
      if (!user) throw new Error("AUTH_REQUIRED");
      const existing = (query.data ?? []).find((r) => r.product_id === productId);
      if (existing) {
        const { error } = await supabase.from("wishlist_items").delete().eq("id", existing.id);
        if (error) throw error;
        return "removed" as const;
      }
      const { error } = await supabase
        .from("wishlist_items")
        .insert({ user_id: user.id, product_id: productId });
      if (error) throw error;
      return "added" as const;
    },
    onSuccess: (res) => {
      qc.invalidateQueries({ queryKey: ["wishlist"] });
      toast.success(res === "added" ? "Saved to your royal collection" : "Removed from wishlist");
    },
    onError: (e: Error) =>
      toast.error(
        e.message === "AUTH_REQUIRED" ? "Sign in to save pieces to your wishlist" : e.message,
      ),
  });

  return { ...query, items: query.data ?? [], ids, toggle };
}
