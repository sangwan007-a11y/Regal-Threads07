import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

const KEYS = [
  "products",
  "product",
  "variants",
  "categories",
  "collections",
  "coupons",
  "admin-products",
  "admin-inventory",
  "admin-coupons",
  "admin-stats",
];

/** Keeps every catalogue view in sync with live database changes. */
export function useCatalogRealtime() {
  const qc = useQueryClient();

  useEffect(() => {
    const invalidate = () => {
      for (const key of KEYS) qc.invalidateQueries({ queryKey: [key] });
    };

    const channel = supabase
      .channel("catalog-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "products" }, invalidate)
      .on("postgres_changes", { event: "*", schema: "public", table: "product_images" }, invalidate)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "product_variants" },
        invalidate,
      )
      .on("postgres_changes", { event: "*", schema: "public", table: "coupons" }, invalidate)
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [qc]);
}

export function CatalogRealtime() {
  useCatalogRealtime();
  return null;
}
