import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./useAuth";
import type { Product } from "@/lib/catalog";

export type CartRow = {
  id: string;
  product_id: string;
  size: string;
  color: string;
  quantity: number;
  products: Product;
};

export function useCart() {
  const { user } = useAuth();
  const qc = useQueryClient();

  const query = useQuery({
    queryKey: ["cart", user?.id],
    enabled: !!user,
    queryFn: async (): Promise<CartRow[]> => {
      const { data, error } = await supabase
        .from("cart_items")
        .select("id,product_id,size,color,quantity, products(*, product_images(id,url,alt,sort_order))")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as CartRow[];
    },
  });

  const invalidate = () => qc.invalidateQueries({ queryKey: ["cart"] });

  const add = useMutation({
    mutationFn: async (input: {
      productId: string;
      size: string;
      color: string;
      quantity?: number;
    }) => {
      if (!user) throw new Error("AUTH_REQUIRED");
      const existing = (query.data ?? []).find(
        (r) => r.product_id === input.productId && r.size === input.size && r.color === input.color,
      );
      if (existing) {
        const { error } = await supabase
          .from("cart_items")
          .update({ quantity: existing.quantity + (input.quantity ?? 1) })
          .eq("id", existing.id);
        if (error) throw error;
        return;
      }
      const { error } = await supabase.from("cart_items").insert({
        user_id: user.id,
        product_id: input.productId,
        size: input.size,
        color: input.color,
        quantity: input.quantity ?? 1,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate();
      toast.success("Added to your royal cart");
    },
    onError: (e: Error) =>
      toast.error(e.message === "AUTH_REQUIRED" ? "Please sign in to continue" : e.message),
  });

  const setQuantity = useMutation({
    mutationFn: async ({ id, quantity }: { id: string; quantity: number }) => {
      if (quantity < 1) {
        const { error } = await supabase.from("cart_items").delete().eq("id", id);
        if (error) throw error;
        return;
      }
      const { error } = await supabase.from("cart_items").update({ quantity }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("cart_items").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      invalidate();
      toast.success("Removed from cart");
    },
  });

  const clear = useMutation({
    mutationFn: async () => {
      if (!user) return;
      const { error } = await supabase.from("cart_items").delete().eq("user_id", user.id);
      if (error) throw error;
    },
    onSuccess: invalidate,
  });

  const items = query.data ?? [];
  const subtotal = items.reduce((s, i) => s + Number(i.products?.mrp ?? 0) * i.quantity, 0);
  const payable = items.reduce((s, i) => s + Number(i.products?.price ?? 0) * i.quantity, 0);
  const count = items.reduce((s, i) => s + i.quantity, 0);

  return { ...query, items, subtotal, payable, count, add, setQuantity, remove, clear };
}
