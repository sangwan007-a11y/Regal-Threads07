import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { toast } from "sonner";
import { Container } from "@/components/common/Section";
import { EmptyState } from "@/components/common/States";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useCart } from "@/hooks/useCart";
import { inr } from "@/lib/format";
import { SITE } from "@/config/site";
import { whatsappUrl } from "@/lib/whatsapp";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout | Regal Threads" },
      { name: "description", content: "Complete your Regal Threads order with cash on delivery." },
      { property: "og:title", content: "Checkout | Regal Threads" },
      { property: "og:description", content: "Secure checkout for your royal couture." },
    ],
  }),
  component: () => (
    <RequireAuth title="Sign in to check out">
      <CheckoutPage />
    </RequireAuth>
  ),
});

const addressSchema = z.object({
  full_name: z.string().trim().min(2, { message: "Enter your full name" }).max(100),
  phone: z
    .string()
    .trim()
    .regex(/^[0-9]{10}$/, { message: "Enter a valid 10-digit phone number" }),
  email: z.string().trim().email({ message: "Enter a valid email" }).max(255).or(z.literal("")),
  line1: z.string().trim().min(5, { message: "Enter your address" }).max(250),
  city: z.string().trim().min(2, { message: "Enter your city" }).max(80),
  state: z.string().trim().min(2, { message: "Enter your state" }).max(80),
  pincode: z.string().trim().regex(/^[0-9]{6}$/, { message: "Enter a valid 6-digit pincode" }),
});

type Coupon = {
  id: string;
  code: string;
  discount_type: string;
  discount_value: number;
  min_order_amount: number;
  max_discount: number | null;
};

function CheckoutPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { items, payable, subtotal, clear } = useCart();
  const [couponCode, setCouponCode] = useState("");
  const [coupon, setCoupon] = useState<Coupon | null>(null);

  const { data: profile } = useQuery({
    queryKey: ["profile", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("profiles")
        .select("full_name,phone,email")
        .eq("id", user!.id)
        .maybeSingle();
      return data;
    },
  });

  const couponDiscount = (() => {
    if (!coupon) return 0;
    if (payable < Number(coupon.min_order_amount)) return 0;
    const raw =
      coupon.discount_type === "percent"
        ? (payable * Number(coupon.discount_value)) / 100
        : Number(coupon.discount_value);
    return Math.round(Math.min(raw, Number(coupon.max_discount ?? raw)));
  })();

  const afterCoupon = Math.max(payable - couponDiscount, 0);
  const delivery = afterCoupon >= SITE.freeDeliveryAbove || afterCoupon === 0 ? 0 : SITE.deliveryFee;
  const total = afterCoupon + delivery;

  const applyCoupon = useMutation({
    mutationFn: async () => {
      const code = couponCode.trim().toUpperCase();
      if (!code) throw new Error("Enter a coupon code");
      const { data, error } = await supabase
        .from("coupons")
        .select("id,code,discount_type,discount_value,min_order_amount,max_discount")
        .eq("code", code)
        .eq("is_active", true)
        .maybeSingle();
      if (error) throw error;
      if (!data) throw new Error("That coupon isn't valid");
      if (payable < Number(data.min_order_amount))
        throw new Error(`Minimum order of ${inr(data.min_order_amount)} required`);
      return data as Coupon;
    },
    onSuccess: (c) => {
      setCoupon(c);
      toast.success(`Coupon ${c.code} applied`);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const placeOrder = useMutation({
    mutationFn: async (form: FormData) => {
      const parsed = addressSchema.safeParse({
        full_name: form.get("full_name"),
        phone: form.get("phone"),
        email: form.get("email") ?? "",
        line1: form.get("line1"),
        city: form.get("city"),
        state: form.get("state"),
        pincode: form.get("pincode"),
      });
      if (!parsed.success) throw new Error(parsed.error.issues[0]!.message);
      const a = parsed.data;

      const { data: order, error } = await supabase
        .from("orders")
        .insert({
          user_id: user!.id,
          customer_name: a.full_name,
          customer_phone: a.phone,
          customer_email: a.email || null,
          address_line1: a.line1,
          city: a.city,
          state: a.state,
          pincode: a.pincode,
          subtotal,
          product_discount: subtotal - payable,
          coupon_code: coupon?.code ?? null,
          coupon_discount: couponDiscount,
          delivery_fee: delivery,
          total,
          payment_method: "cod",
        })
        .select("id,order_number")
        .single();
      if (error) throw error;

      const { error: itemsError } = await supabase.from("order_items").insert(
        items.map((i) => ({
          order_id: order.id,
          product_id: i.product_id,
          product_name: i.products.name,
          image_url: i.products.product_images?.[0]?.url ?? null,
          sku: i.products.sku,
          size: i.size,
          color: i.color,
          quantity: i.quantity,
          unit_price: i.products.price,
        })),
      );
      if (itemsError) throw itemsError;

      if (coupon) {
        await supabase
          .from("coupon_usage")
          .insert({ coupon_id: coupon.id, user_id: user!.id, order_id: order.id });
      }

      await supabase.from("addresses").insert({
        user_id: user!.id,
        full_name: a.full_name,
        phone: a.phone,
        line1: a.line1,
        city: a.city,
        state: a.state,
        pincode: a.pincode,
      });

      await clear.mutateAsync();
      return order;
    },
    onSuccess: (order) => {
      toast.success(`Order ${order.order_number} placed`);
      navigate({ to: "/orders/$id", params: { id: order.id } });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (!items.length) {
    return (
      <Container className="py-24">
        <EmptyState
          title="Nothing to check out"
          description="Add a piece to your cart first."
          action={
            <Button asChild>
              <Link to="/shop">Browse the house</Link>
            </Button>
          }
        />
      </Container>
    );
  }

  return (
    <Container className="py-12 md:py-16">
      <p className="eyebrow">Final Step</p>
      <h1 className="mt-2 text-4xl md:text-5xl">Checkout</h1>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          placeOrder.mutate(new FormData(e.currentTarget));
        }}
        className="mt-10 grid gap-10 lg:grid-cols-[1fr_360px]"
      >
        <div className="glass rounded-sm p-7">
          <h2 className="font-display text-2xl">Delivery details</h2>
          <div className="mt-6 grid gap-5 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="full_name">Full name</Label>
              <Input
                id="full_name"
                name="full_name"
                required
                maxLength={100}
                defaultValue={profile?.full_name ?? ""}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                name="phone"
                inputMode="numeric"
                required
                maxLength={10}
                defaultValue={profile?.phone ?? ""}
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="email">Email (optional)</Label>
              <Input
                id="email"
                name="email"
                type="email"
                maxLength={255}
                defaultValue={profile?.email ?? user?.email ?? ""}
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="line1">Address</Label>
              <Input id="line1" name="line1" required maxLength={250} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="city">City</Label>
              <Input id="city" name="city" required maxLength={80} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="state">State</Label>
              <Input id="state" name="state" required maxLength={80} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="pincode">Pincode</Label>
              <Input id="pincode" name="pincode" inputMode="numeric" required maxLength={6} />
            </div>
          </div>

          <div className="mt-8 rounded-sm border border-border/60 p-5">
            <p className="eyebrow">Payment</p>
            <p className="mt-3 text-sm">Cash on Delivery</p>
            <p className="mt-1 text-xs text-muted-foreground">
              Pay in cash when your order arrives. Online payments coming soon.
            </p>
          </div>
        </div>

        <aside className="lg:sticky lg:top-28 lg:h-fit">
          <div className="glass rounded-sm p-7">
            <h2 className="font-display text-2xl">Summary</h2>

            <div className="mt-5 flex gap-2">
              <Input
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value)}
                placeholder="Coupon code"
                maxLength={24}
                className="uppercase"
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => applyCoupon.mutate()}
                disabled={applyCoupon.isPending}
              >
                Apply
              </Button>
            </div>

            <dl className="mt-6 space-y-3 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Items ({items.length})</dt>
                <dd>{inr(payable)}</dd>
              </div>
              {couponDiscount > 0 && (
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Coupon ({coupon?.code})</dt>
                  <dd className="text-primary">−{inr(couponDiscount)}</dd>
                </div>
              )}
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Delivery</dt>
                <dd>{delivery === 0 ? "Free" : inr(delivery)}</dd>
              </div>
              <div className="mt-4 flex justify-between border-t border-border/60 pt-4 font-display text-xl">
                <dt>Total</dt>
                <dd className="text-primary">{inr(total)}</dd>
              </div>
            </dl>

            <Button type="submit" size="lg" className="mt-7 w-full" disabled={placeOrder.isPending}>
              {placeOrder.isPending ? "Placing order…" : "Place order"}
            </Button>
            <Button asChild variant="secondary" className="mt-2 w-full">
              <a
                href={whatsappUrl(
                  items.map((i) => ({
                    name: i.products.name,
                    sku: i.products.sku,
                    size: i.size,
                    color: i.color,
                    quantity: i.quantity,
                    price: i.products.price,
                  })),
                  `Total: ${inr(total)}`,
                )}
                target="_blank"
                rel="noreferrer"
              >
                Order on WhatsApp instead
              </a>
            </Button>
          </div>
        </aside>
      </form>
    </Container>
  );
}
