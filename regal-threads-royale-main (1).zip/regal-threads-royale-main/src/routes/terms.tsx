import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/common/LegalPage";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms & Conditions | Regal Threads" },
      {
        name: "description",
        content: "The terms that govern purchases and use of the Regal Threads website.",
      },
      { property: "og:title", content: "Terms & Conditions | Regal Threads" },
      { property: "og:description", content: "Terms governing purchases from Regal Threads." },
    ],
  }),
  component: () => (
    <LegalPage
      eyebrow="The Fine Print"
      title="Terms & Conditions"
      sections={[
        {
          heading: "Orders",
          body: [
            "All orders are subject to acceptance and availability. We may cancel an order if a piece becomes unavailable, in which case any payment is refunded in full.",
          ],
        },
        {
          heading: "Pricing",
          body: [
            "Prices are listed in Indian Rupees and are inclusive of applicable taxes. We reserve the right to change prices without notice; the price at the time of order applies.",
          ],
        },
        {
          heading: "Product representation",
          body: [
            "Handcrafted pieces carry small variations in embroidery and colour. Screen colours may differ slightly from the actual fabric.",
          ],
        },
        {
          heading: "Intellectual property",
          body: [
            "All designs, photography and content on this site belong to Regal Threads and may not be reproduced without written permission.",
          ],
        },
      ]}
    />
  ),
});
