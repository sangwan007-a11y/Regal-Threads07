import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { toast } from "sonner";
import { Container } from "@/components/common/Section";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { formatDate, inr } from "@/lib/format";
import { OrderTimeline } from "@/components/order/OrderTimeline";

export const Route = createFileRoute("/track")({
  head: () => ({
    meta: [
      { title: "Track Your Order | Regal Threads" },
      {
        name: "description",
        content: "Enter your Regal Threads order number to see its current delivery status.",
      },
      { property: "og:title", content: "Track Your Order | Regal Threads" },
      { property: "og:description", content: "Follow your royal couture on its way to you." },
    ],
  }),
  component: TrackPage,
});

type Found = {
  order_number: string;
  status: string;
  created_at: string;
  total: number;
  expected_delivery: string | null;
  tracking_info: string | null;
};

function TrackPage() {
  const { user } = useAuth();
  const [order, setOrder] = useState<Found | null>(null);
  const [loading, setLoading] = useState(false);

  const search = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const code = new FormData(e.currentTarget).get("order_number")?.toString().trim().toUpperCase();
    if (!code) return;
    if (!user) { toast.error("Please sign in to track your order"); return; }
    setLoading(true);
    const { data, error } = await supabase
      .from("orders")
      .select("order_number,status,created_at,total,expected_delivery,tracking_info")
      .eq("order_number", code)
      .maybeSingle();
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    if (!data) {
      setOrder(null);
      { toast.error("No order found with that number"); return; }
    }
    setOrder(data as Found);
  };

  return (
    <Container className="py-14 md:py-20">
      <div className="mx-auto max-w-xl">
        <p className="eyebrow text-center">Where is it?</p>
        <h1 className="mt-2 text-center text-4xl md:text-5xl">Track your order</h1>
        <p className="mt-4 text-center text-sm text-muted-foreground">
          Enter the order number from your confirmation, e.g. RT24051200123.
        </p>

        <form onSubmit={search} className="glass mt-8 rounded-sm p-7">
          <div className="space-y-2">
            <Label htmlFor="order_number">Order number</Label>
            <Input id="order_number" name="order_number" required maxLength={24} />
          </div>
          <Button type="submit" className="mt-5 w-full" disabled={loading}>
            Track order
          </Button>
        </form>

        {order && (
          <div className="glass mt-6 rounded-sm p-7">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-2xl">{order.order_number}</h2>
              <span className="text-sm">{inr(order.total)}</span>
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              Placed {formatDate(order.created_at)}
              {order.expected_delivery && ` · Expected ${formatDate(order.expected_delivery)}`}
            </p>
            <div className="mt-6">
              <OrderTimeline status={order.status} />
            </div>
            {order.tracking_info && (
              <p className="mt-5 text-xs text-muted-foreground">{order.tracking_info}</p>
            )}
          </div>
        )}
      </div>
    </Container>
  );
}
