import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/common/LegalPage";
import { SITE } from "@/config/site";

export const Route = createFileRoute("/privacy-policy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy | Regal Threads" },
      {
        name: "description",
        content: "How Regal Threads collects, uses and protects your personal information.",
      },
      { property: "og:title", content: "Privacy Policy | Regal Threads" },
      { property: "og:description", content: "Your data, handled with care." },
    ],
  }),
  component: () => (
    <LegalPage
      eyebrow="Your Data"
      title="Privacy Policy"
      intro="We collect only what we need to deliver your order and improve your experience."
      sections={[
        {
          heading: "What we collect",
          body: [
            "Account details (name, email, phone), delivery addresses, order history and wishlist activity.",
            "We never store card details — cash on delivery is currently our only payment method.",
          ],
        },
        {
          heading: "How we use it",
          body: [
            "To process and deliver orders, provide styling support, and send order updates. We do not sell your data to third parties.",
          ],
        },
        {
          heading: "Your rights",
          body: [
            `You can update or delete your account information at any time from your account page, or write to ${SITE.email}.`,
          ],
        },
      ]}
    />
  ),
});
