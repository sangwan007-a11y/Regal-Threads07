import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Heart, MessageCircle, RotateCcw, ShieldCheck, Truck } from "lucide-react";
import { motion } from "motion/react";
import { Container, Reveal, SectionHeading } from "@/components/common/Section";
import { Stars } from "@/components/common/Stars";
import { EmptyState, ProductGridSkeleton } from "@/components/common/States";
import { ProductGrid } from "@/components/product/ProductCard";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { discountPercent, formatDate, inr } from "@/lib/format";
import { productQuery, productsQuery, reviewsQuery, variantsQuery } from "@/lib/catalog";
import { useCart } from "@/hooks/useCart";
import { useWishlist } from "@/hooks/useWishlist";
import { whatsappUrl } from "@/lib/whatsapp";
import { SITE } from "@/config/site";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/product/$slug")({
  head: ({ params }) => {
    const pretty = params.slug
      .split("-")
      .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
      .join(" ");
    return {
      meta: [
        { title: `${pretty} | Regal Threads` },
        {
          name: "description",
          content: `${pretty} — handcrafted Indian royal couture from Regal Threads. Free shipping above ₹${SITE.freeDeliveryAbove}.`,
        },
        { property: "og:title", content: `${pretty} | Regal Threads` },
        { property: "og:description", content: `${pretty} from the Regal Threads atelier.` },
      ],
    };
  },
  component: ProductPage,
});

function ProductPage() {
  const { slug } = Route.useParams();
  const { data: product, isLoading } = useQuery(productQuery(slug));
  const { data: variants } = useQuery(variantsQuery(product?.id));
  const { data: reviews } = useQuery(reviewsQuery(product?.id));
  const { add } = useCart();
  const { ids, toggle } = useWishlist();

  const [size, setSize] = useState<string | null>(null);
  const [color, setColor] = useState<string | null>(null);
  const [active, setActive] = useState(0);

  const images = useMemo(
    () => [...(product?.product_images ?? [])].sort((a, b) => a.sort_order - b.sort_order),
    [product],
  );

  const related = useQuery(
    productsQuery({ gender: product?.gender ?? "men", limit: 8 }),
  );

  if (isLoading) {
    return (
      <Container className="grid gap-10 py-14 lg:grid-cols-2">
        <Skeleton className="aspect-[3/4] rounded-sm" />
        <div className="space-y-4">
          <Skeleton className="h-10 w-2/3" />
          <Skeleton className="h-5 w-1/3" />
          <Skeleton className="h-28 w-full" />
        </div>
      </Container>
    );
  }

  if (!product) {
    return (
      <Container className="py-24">
        <EmptyState
          title="This piece has left the court"
          description="The product you're looking for is no longer available."
          action={
            <Button asChild>
              <Link to="/shop">Browse the house</Link>
            </Button>
          }
        />
      </Container>
    );
  }

  const off = discountPercent(product.mrp, product.price);
  const saved = ids.has(product.id);
  const stockFor = (s: string, c: string) =>
    (variants ?? []).find((v) => v.size === s && v.color === c)?.stock ?? 0;
  const selectedStock = size && color ? stockFor(size, color) : null;
  const canAdd = !!size && !!color && (selectedStock ?? 0) > 0;

  const relatedProducts = (related.data ?? []).filter((p) => p.id !== product.id).slice(0, 4);

  return (
    <>
      <Container className="py-10 md:py-14">
        <nav className="mb-8 text-[0.66rem] tracking-[0.2em] uppercase text-muted-foreground">
          <Link to="/" className="hover:text-primary">
            Home
          </Link>
          <span className="mx-2">/</span>
          <Link to="/shop" className="hover:text-primary">
            Shop
          </Link>
          <span className="mx-2">/</span>
          <span className="text-foreground">{product.name}</span>
        </nav>

        <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
          <div>
            <motion.div
              key={active}
              initial={{ opacity: 0.4 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.4 }}
              className="relative aspect-[3/4] overflow-hidden rounded-sm bg-surface"
            >
              <img
                src={images[active]?.url ?? "/images/hero.jpg"}
                alt={images[active]?.alt ?? product.name}
                className="size-full object-cover"
              />
              {off > 0 && (
                <span className="absolute left-4 top-4 rounded-full bg-secondary px-3 py-1.5 text-[0.6rem] tracking-[0.2em] uppercase text-secondary-foreground">
                  {off}% Off
                </span>
              )}
            </motion.div>
            {images.length > 1 && (
              <div className="no-scrollbar mt-4 flex gap-3 overflow-x-auto">
                {images.map((img, i) => (
                  <button
                    key={img.id}
                    type="button"
                    onClick={() => setActive(i)}
                    className={cn(
                      "aspect-[3/4] w-20 shrink-0 overflow-hidden rounded-sm border transition-colors",
                      i === active ? "border-primary" : "border-transparent opacity-70",
                    )}
                  >
                    <img src={img.url} alt="" className="size-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="lg:pt-4">
            <p className="eyebrow">{product.categories?.name ?? product.gender}</p>
            <h1 className="mt-3 text-4xl leading-tight md:text-5xl">{product.name}</h1>

            <div className="mt-4 flex items-center gap-3">
              <Stars rating={Number(product.rating)} />
              <span className="text-xs text-muted-foreground">
                {Number(product.rating).toFixed(1)} · {product.review_count} reviews
              </span>
            </div>

            <div className="mt-6 flex items-baseline gap-3">
              <span className="font-display text-3xl text-primary">{inr(product.price)}</span>
              {off > 0 && (
                <>
                  <span className="text-sm text-muted-foreground line-through">
                    {inr(product.mrp)}
                  </span>
                  <span className="text-xs tracking-widest uppercase text-accent-foreground">
                    Save {inr(Number(product.mrp) - Number(product.price))}
                  </span>
                </>
              )}
            </div>
            <p className="mt-1 text-xs text-muted-foreground">Inclusive of all taxes</p>

            {product.description && (
              <p className="mt-6 text-sm leading-relaxed text-muted-foreground">
                {product.description}
              </p>
            )}

            <div className="mt-8">
              <p className="eyebrow mb-3">Colour</p>
              <div className="flex flex-wrap gap-2">
                {product.colors.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColor(c)}
                    className={cn(
                      "rounded-sm border px-4 py-2 text-xs tracking-widest transition-colors",
                      color === c
                        ? "border-primary text-primary"
                        : "border-border text-muted-foreground hover:border-primary/50",
                    )}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-6">
              <p className="eyebrow mb-3">Size</p>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((s) => {
                  const out = color ? stockFor(s, color) === 0 : false;
                  return (
                    <button
                      key={s}
                      type="button"
                      disabled={out}
                      onClick={() => setSize(s)}
                      className={cn(
                        "min-w-12 rounded-sm border px-4 py-2 text-xs tracking-widest transition-colors",
                        size === s
                          ? "border-primary text-primary"
                          : "border-border text-muted-foreground hover:border-primary/50",
                        out && "cursor-not-allowed line-through opacity-40",
                      )}
                    >
                      {s}
                    </button>
                  );
                })}
              </div>
              {selectedStock !== null && selectedStock > 0 && selectedStock <= 3 && (
                <p className="mt-3 text-xs text-primary">Only {selectedStock} left in this size</p>
              )}
              {selectedStock === 0 && size && color && (
                <p className="mt-3 text-xs text-destructive">This combination is sold out</p>
              )}
            </div>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Button
                size="lg"
                className="flex-1"
                disabled={!canAdd || add.isPending}
                onClick={() =>
                  add.mutate({ productId: product.id, size: size!, color: color!, quantity: 1 })
                }
              >
                {size && color ? "Add to Cart" : "Select size & colour"}
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => toggle.mutate(product.id)}
                aria-label="Wishlist"
              >
                <Heart className={cn("size-4", saved && "fill-primary text-primary")} />
              </Button>
            </div>

            <Button asChild size="lg" variant="secondary" className="mt-3 w-full">
              <a
                href={whatsappUrl([
                  {
                    name: product.name,
                    sku: product.sku,
                    size,
                    color,
                    quantity: 1,
                    price: product.price,
                  },
                ])}
                target="_blank"
                rel="noreferrer"
              >
                <MessageCircle className="mr-2 size-4" /> Order on WhatsApp
              </a>
            </Button>

            <div className="mt-8 grid grid-cols-3 gap-px overflow-hidden rounded-sm border border-border/60 bg-border/60 text-center">
              {[
                { icon: Truck, label: "Free above ₹4,999" },
                { icon: RotateCcw, label: "7-day returns" },
                { icon: ShieldCheck, label: "Authentic craft" },
              ].map((x) => (
                <div key={x.label} className="bg-background px-2 py-5">
                  <x.icon className="mx-auto size-4 text-primary" />
                  <p className="mt-2 text-[0.62rem] tracking-[0.12em] uppercase text-muted-foreground">
                    {x.label}
                  </p>
                </div>
              ))}
            </div>

            <Accordion type="single" collapsible className="mt-10" defaultValue="details">
              <AccordionItem value="details">
                <AccordionTrigger className="font-display text-lg">Product details</AccordionTrigger>
                <AccordionContent className="space-y-2 text-sm text-muted-foreground">
                  <p>SKU: {product.sku}</p>
                  {product.fabric && <p>Fabric: {product.fabric}</p>}
                  {product.occasion && <p>Occasion: {product.occasion}</p>}
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="care">
                <AccordionTrigger className="font-display text-lg">Care</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground">
                  {product.care ?? "Dry clean only. Store in a muslin bag away from sunlight."}
                </AccordionContent>
              </AccordionItem>
              <AccordionItem value="shipping">
                <AccordionTrigger className="font-display text-lg">
                  Shipping & returns
                </AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground">
                  Dispatched in 2–4 business days. Free delivery above {inr(SITE.freeDeliveryAbove)}.
                  Returns accepted within 7 days of delivery on unworn pieces.
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
      </Container>

      <Container className="py-14">
        <SectionHeading eyebrow="Patron Reviews" title="What the court says" align="left" />
        {(reviews ?? []).length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No reviews yet — be the first to celebrate this piece.
          </p>
        ) : (
          <div className="grid gap-5 md:grid-cols-2">
            {(reviews ?? []).map((r, i) => (
              <Reveal key={r.id} delay={i * 0.05}>
                <article className="glass h-full rounded-sm p-6">
                  <div className="flex items-center justify-between">
                    <Stars rating={Number(r.rating)} />
                    <span className="text-xs text-muted-foreground">{formatDate(r.created_at)}</span>
                  </div>
                  {r.body && <p className="mt-4 text-sm leading-relaxed">{r.body}</p>}
                  <p className="mt-4 text-[0.66rem] tracking-[0.2em] uppercase text-muted-foreground">
                    {r.author_name}
                    {r.is_verified && <span className="ml-2 text-primary">Verified buyer</span>}
                  </p>
                </article>
              </Reveal>
            ))}
          </div>
        )}
      </Container>

      <Container className="pb-20">
        <SectionHeading eyebrow="Complete the Look" title="You may also like" align="left" />
        {related.isLoading ? (
          <ProductGridSkeleton count={4} />
        ) : (
          <ProductGrid products={relatedProducts} />
        )}
      </Container>
    </>
  );
}
