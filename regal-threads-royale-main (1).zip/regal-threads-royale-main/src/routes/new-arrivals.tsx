import { createFileRoute } from "@tanstack/react-router";
import { ShopView } from "@/components/shop/ShopView";

export const Route = createFileRoute("/new-arrivals")({
  head: () => ({
    meta: [
      { title: "New Arrivals — Fresh Couture | Regal Threads" },
      {
        name: "description",
        content: "The newest hand-embroidered arrivals from the Regal Threads atelier.",
      },
      { property: "og:title", content: "New Arrivals | Regal Threads" },
      { property: "og:description", content: "Just landed: the season's newest royal couture." },
    ],
  }),
  component: () => (
    <ShopView
      title="New Arrivals"
      eyebrow="Just Landed"
      description="The latest pieces to leave our atelier."
      base={{ flag: "new", sort: "newest" }}
    />
  ),
});
