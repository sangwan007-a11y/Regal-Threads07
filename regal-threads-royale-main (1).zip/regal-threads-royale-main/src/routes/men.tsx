import { createFileRoute } from "@tanstack/react-router";
import { ShopView } from "@/components/shop/ShopView";

export const Route = createFileRoute("/men")({
  head: () => ({
    meta: [
      { title: "Men's Royal Wear — Sherwanis & Bandhgalas | Regal Threads" },
      {
        name: "description",
        content:
          "Shop handcrafted sherwanis, bandhgalas, indo-western sets and kurta sets for weddings and festivals.",
      },
      { property: "og:title", content: "Men's Royal Wear | Regal Threads" },
      {
        property: "og:description",
        content: "Sherwanis, bandhgalas and festive kurta sets, hand-embroidered.",
      },
    ],
  }),
  component: () => (
    <ShopView title="Men" eyebrow="The Maharaja Court" base={{ gender: "men" }} heroImage="/images/men.jpg" />
  ),
});
