import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/common/LegalPage";
import { SITE } from "@/config/site";
import { inr } from "@/lib/format";

export const Route = createFileRoute("/shipping-policy")({
  head: () => ({
    meta: [
      { title: "Shipping Policy | Regal Threads" },
      {
        name: "description",
        content: "Delivery timelines, shipping charges and dispatch details for Regal Threads orders.",
      },
      { property: "og:title", content: "Shipping Policy | Regal Threads" },
      { property: "og:description", content: "How and when your couture reaches you." },
    ],
  }),
  component: () => (
    <LegalPage
      eyebrow="Delivery"
      title="Shipping Policy"
      intro="How and when your Regal Threads order reaches your door."
      sections={[
        {
          heading: "Dispatch timelines",
          body: [
            "Ready-to-ship pieces are dispatched within 2–4 business days of order confirmation.",
            "Made-to-order and custom embroidery pieces take 10–21 business days depending on the craft involved. Our stylists confirm the timeline on WhatsApp after you order.",
          ],
        },
        {
          heading: "Delivery charges",
          body: [
            `Delivery is free on all orders above ${inr(SITE.freeDeliveryAbove)}. Below that, a flat fee of ${inr(SITE.deliveryFee)} applies.`,
            "We currently deliver across India. For international shipping, message us on WhatsApp for a quote.",
          ],
        },
        {
          heading: "Tracking",
          body: [
            "Every order receives an RT order number. Track its progress from the Track Order page or your account.",
          ],
        },
      ]}
    />
  ),
});
