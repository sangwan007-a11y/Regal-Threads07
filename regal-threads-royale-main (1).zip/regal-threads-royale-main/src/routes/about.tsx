import { createFileRoute, Link } from "@tanstack/react-router";
import { Container, Reveal, SectionHeading } from "@/components/common/Section";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "Our Story — The House of Regal Threads" },
      {
        name: "description",
        content:
          "Regal Threads revives the craft of Indian royal ateliers with hand-embroidered couture for modern celebrations.",
      },
      { property: "og:title", content: "Our Story | Regal Threads" },
      { property: "og:description", content: "The house behind the hand-embroidered couture." },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <>
      <div className="relative h-[50vh] min-h-[320px] overflow-hidden">
        <img src="/images/wedding.jpg" alt="Regal Threads atelier" className="size-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-background/20" />
        <Container className="absolute inset-0 flex flex-col justify-end pb-10">
          <p className="eyebrow">Est. In Craft</p>
          <h1 className="mt-2 text-4xl md:text-6xl">The House of Regal Threads</h1>
        </Container>
      </div>

      <Container className="py-16 md:py-24">
        <div className="mx-auto max-w-3xl space-y-6 text-sm leading-relaxed text-muted-foreground md:text-base">
          <p className="font-display text-2xl leading-snug text-foreground md:text-3xl">
            We began with a simple belief — that Indian celebrations deserve clothing worthy of the
            courts they descend from.
          </p>
          <p>
            Every Regal Threads piece begins in a sketchbook and ends on a karigar's frame. Zardozi,
            resham, gota patti and dabka work are applied by hand over weeks, on fabrics sourced from
            Banaras, Surat and Kanchipuram.
          </p>
          <p>
            Our silhouettes are modern — lighter canvases, cleaner shoulders, breathable linings — but
            the ornamentation stays uncompromisingly royal. The result is couture you can dance in
            until the last song.
          </p>
        </div>
      </Container>

      <Container className="pb-20">
        <SectionHeading eyebrow="What We Stand For" title="Our promises" />
        <div className="grid gap-5 md:grid-cols-3">
          {[
            {
              title: "Handcrafted, always",
              copy: "No machine shortcuts on our signature embroidery — each piece carries the karigar's hand.",
            },
            {
              title: "Fair to the makers",
              copy: "We work directly with artisan clusters and pay per craft-hour, not per piece.",
            },
            {
              title: "Made to last",
              copy: "Reinforced seams, natural fibres and finishing designed to be passed down.",
            },
          ].map((v, i) => (
            <Reveal key={v.title} delay={i * 0.08}>
              <div className="glass h-full rounded-sm p-7">
                <h3 className="font-display text-2xl">{v.title}</h3>
                <p className="mt-3 text-sm text-muted-foreground">{v.copy}</p>
              </div>
            </Reveal>
          ))}
        </div>

        <div className="mt-14 text-center">
          <Button asChild size="lg">
            <Link to="/shop">Explore the collection</Link>
          </Button>
        </div>
      </Container>
    </>
  );
}
