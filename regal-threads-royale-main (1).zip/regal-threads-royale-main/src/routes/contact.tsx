import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { toast } from "sonner";
import { Mail, MessageCircle, Instagram } from "lucide-react";
import { Container } from "@/components/common/Section";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { SITE } from "@/config/site";
import { whatsappEnquiryUrl } from "@/lib/whatsapp";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Regal Threads — Styling & Support" },
      {
        name: "description",
        content:
          "Reach the Regal Threads team on WhatsApp or email for styling advice, sizing help and order support.",
      },
      { property: "og:title", content: "Contact | Regal Threads" },
      { property: "og:description", content: "Styling advice and order support, whenever you need." },
    ],
  }),
  component: ContactPage,
});

const schema = z.object({
  name: z.string().trim().min(2, { message: "Enter your name" }).max(100),
  email: z.string().trim().email({ message: "Enter a valid email" }).max(255),
  message: z.string().trim().min(10, { message: "Tell us a little more" }).max(1000),
});

function ContactPage() {
  const submit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const parsed = schema.safeParse({
      name: form.get("name"),
      email: form.get("email"),
      message: form.get("message"),
    });
    if (!parsed.success) { toast.error(parsed.error.issues[0]!.message); return; }
    window.open(
      whatsappEnquiryUrl(
        `Hello ${SITE.name}, I'm ${parsed.data.name} (${parsed.data.email}).\n\n${parsed.data.message}`,
      ),
      "_blank",
      "noopener",
    );
    toast.success("Opening WhatsApp with your message");
    e.currentTarget.reset();
  };

  return (
    <Container className="py-14 md:py-20">
      <div className="grid gap-12 lg:grid-cols-2">
        <div>
          <p className="eyebrow">We're Listening</p>
          <h1 className="mt-2 text-4xl md:text-6xl">Contact the house</h1>
          <p className="mt-5 max-w-md text-sm leading-relaxed text-muted-foreground">
            Sizing questions, custom embroidery, wedding wardrobes for the whole family — our
            stylists reply within a few hours.
          </p>

          <div className="mt-10 space-y-4">
            <a
              href={whatsappEnquiryUrl("Hello Regal Threads!")}
              target="_blank"
              rel="noreferrer"
              className="glass flex items-center gap-4 rounded-sm p-5 transition-colors hover:text-primary"
            >
              <MessageCircle className="size-5 text-primary" />
              <span className="text-sm">Chat with a stylist on WhatsApp</span>
            </a>
            <a
              href={`mailto:${SITE.email}`}
              className="glass flex items-center gap-4 rounded-sm p-5 transition-colors hover:text-primary"
            >
              <Mail className="size-5 text-primary" />
              <span className="text-sm">{SITE.email}</span>
            </a>
            <a
              href={SITE.instagram}
              target="_blank"
              rel="noreferrer"
              className="glass flex items-center gap-4 rounded-sm p-5 transition-colors hover:text-primary"
            >
              <Instagram className="size-5 text-primary" />
              <span className="text-sm">Follow our latest drops</span>
            </a>
          </div>
        </div>

        <form onSubmit={submit} className="glass h-fit rounded-sm p-7 md:p-9">
          <h2 className="font-display text-2xl">Send a message</h2>
          <div className="mt-6 space-y-5">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input id="name" name="name" required maxLength={100} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" name="email" type="email" required maxLength={255} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="message">Message</Label>
              <Textarea id="message" name="message" rows={5} required maxLength={1000} />
            </div>
            <Button type="submit" className="w-full">
              Send via WhatsApp
            </Button>
          </div>
        </form>
      </div>
    </Container>
  );
}
