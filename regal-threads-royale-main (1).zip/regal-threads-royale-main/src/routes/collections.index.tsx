import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Container, Reveal, SectionHeading } from "@/components/common/Section";
import { EmptyState } from "@/components/common/States";
import { Skeleton } from "@/components/ui/skeleton";
import { collectionsQuery } from "@/lib/catalog";

export const Route = createFileRoute("/collections/")({
  head: () => ({
    meta: [
      { title: "Royal Collections | Regal Threads" },
      {
        name: "description",
        content:
          "Explore the Maharaja, Maharani, Wedding Royalty and festive collections from Regal Threads.",
      },
      { property: "og:title", content: "Royal Collections | Regal Threads" },
      { property: "og:description", content: "Curated worlds of Indian royal couture." },
    ],
  }),
  component: CollectionsPage,
});

function CollectionsPage() {
  const { data, isLoading } = useQuery(collectionsQuery());
  const collections = data ?? [];

  return (
    <Container className="py-14 md:py-20">
      <SectionHeading
        eyebrow="Curated Worlds"
        title="Our royal collections"
        description="Each collection is a chapter — grandeur, celebration and heirloom craft."
      />
      {isLoading ? (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="aspect-[4/3] rounded-sm" />
          ))}
        </div>
      ) : collections.length === 0 ? (
        <EmptyState title="Collections are being curated" />
      ) : (
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {collections.map((c, i) => (
            <Reveal key={c.id} delay={i * 0.06}>
              <Link
                to="/collections/$slug"
                params={{ slug: c.slug }}
                className="group relative block aspect-[4/3] overflow-hidden rounded-sm"
              >
                <img
                  src={c.image_url ?? "/images/wedding.jpg"}
                  alt={c.name}
                  loading="lazy"
                  className="size-full object-cover transition-transform duration-1000 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-background/45 transition-colors group-hover:bg-background/25" />
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                  <h2 className="font-display text-3xl">{c.name}</h2>
                  {c.tagline && (
                    <p className="mt-2 text-[0.66rem] tracking-[0.24em] uppercase text-primary">
                      {c.tagline}
                    </p>
                  )}
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      )}
    </Container>
  );
}
