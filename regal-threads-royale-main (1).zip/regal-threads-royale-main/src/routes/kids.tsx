import { createFileRoute } from "@tanstack/react-router";
import { ShopView } from "@/components/shop/ShopView";

export const Route = createFileRoute("/kids")({
  head: () => ({
    meta: [
      { title: "Kids' Festive Wear — Little Royals | Regal Threads" },
      {
        name: "description",
        content: "Tiny sherwanis, lehengas and kurta sets for the littlest royals in the family.",
      },
      { property: "og:title", content: "Kids' Festive Wear | Regal Threads" },
      { property: "og:description", content: "Sherwanis and lehengas made for little royals." },
    ],
  }),
  component: () => (
    <ShopView title="Kids" eyebrow="Little Royals" base={{ gender: "kids" }} heroImage="/images/kids.jpg" />
  ),
});
