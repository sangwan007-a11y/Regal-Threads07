import { createFileRoute } from "@tanstack/react-router";
import { ShopView } from "@/components/shop/ShopView";

export const Route = createFileRoute("/offers")({
  head: () => ({
    meta: [
      { title: "Offers & Festive Deals | Regal Threads" },
      {
        name: "description",
        content: "Limited-time savings on sherwanis, lehengas and festive couture.",
      },
      { property: "og:title", content: "Offers & Festive Deals | Regal Threads" },
      { property: "og:description", content: "Royal couture at limited-time festive prices." },
    ],
  }),
  component: () => (
    <ShopView
      title="Offers"
      eyebrow="Festive Savings"
      description="Discounted pieces from across the house — while stocks last."
      base={{ minDiscount: 10, sort: "discount" }}
      heroImage="/images/festive.jpg"
    />
  ),
});
