import { createFileRoute, Link } from "@tanstack/react-router";
import { Minus, Plus, Trash2 } from "lucide-react";
import { Container } from "@/components/common/Section";
import { EmptyState } from "@/components/common/States";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useCart } from "@/hooks/useCart";
import { inr } from "@/lib/format";
import { primaryImage } from "@/lib/catalog";
import { SITE } from "@/config/site";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Your Cart | Regal Threads" },
      { name: "description", content: "Review the royal pieces in your Regal Threads cart." },
      { property: "og:title", content: "Your Cart | Regal Threads" },
      { property: "og:description", content: "Review your selected couture before checkout." },
    ],
  }),
  component: () => (
    <RequireAuth title="Sign in to view your cart">
      <CartPage />
    </RequireAuth>
  ),
});

function CartPage() {
  const { items, isLoading, payable, subtotal, setQuantity, remove } = useCart();
  const delivery = payable >= SITE.freeDeliveryAbove || payable === 0 ? 0 : SITE.deliveryFee;

  if (isLoading) {
    return (
      <Container className="space-y-4 py-16">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-32 w-full" />
      </Container>
    );
  }

  if (!items.length) {
    return (
      <Container className="py-24">
        <EmptyState
          title="Your cart awaits its treasures"
          description="Nothing here yet — explore the house and find your next entrance."
          action={
            <Button asChild>
              <Link to="/shop">Start shopping</Link>
            </Button>
          }
        />
      </Container>
    );
  }

  return (
    <Container className="py-12 md:py-16">
      <p className="eyebrow">Your Selection</p>
      <h1 className="mt-2 text-4xl md:text-5xl">Shopping Cart</h1>

      <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_360px]">
        <div className="space-y-4">
          {items.map((item) => (
            <div key={item.id} className="glass flex gap-4 rounded-sm p-4">
              <Link
                to="/product/$slug"
                params={{ slug: item.products.slug }}
                className="aspect-[3/4] w-24 shrink-0 overflow-hidden rounded-sm"
              >
                <img
                  src={primaryImage(item.products)}
                  alt={item.products.name}
                  className="size-full object-cover"
                />
              </Link>
              <div className="flex flex-1 flex-col justify-between">
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <Link to="/product/$slug" params={{ slug: item.products.slug }}>
                      <h2 className="font-display text-xl leading-snug hover:text-primary">
                        {item.products.name}
                      </h2>
                    </Link>
                    <button
                      type="button"
                      aria-label="Remove item"
                      onClick={() => remove.mutate(item.id)}
                      className="text-muted-foreground transition-colors hover:text-destructive"
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                  <p className="mt-1 text-[0.66rem] tracking-[0.18em] uppercase text-muted-foreground">
                    {item.color} · Size {item.size}
                  </p>
                </div>

                <div className="mt-4 flex items-center justify-between">
                  <div className="flex items-center gap-1 rounded-sm border border-border">
                    <button
                      type="button"
                      aria-label="Decrease quantity"
                      className="grid size-8 place-items-center text-muted-foreground hover:text-primary"
                      onClick={() =>
                        setQuantity.mutate({ id: item.id, quantity: item.quantity - 1 })
                      }
                    >
                      <Minus className="size-3.5" />
                    </button>
                    <span className="w-8 text-center text-sm">{item.quantity}</span>
                    <button
                      type="button"
                      aria-label="Increase quantity"
                      className="grid size-8 place-items-center text-muted-foreground hover:text-primary"
                      onClick={() =>
                        setQuantity.mutate({ id: item.id, quantity: item.quantity + 1 })
                      }
                    >
                      <Plus className="size-3.5" />
                    </button>
                  </div>
                  <span className="font-medium">
                    {inr(Number(item.products.price) * item.quantity)}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <aside className="lg:sticky lg:top-28 lg:h-fit">
          <div className="glass rounded-sm p-7">
            <h2 className="font-display text-2xl">Order summary</h2>
            <dl className="mt-6 space-y-3 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">MRP total</dt>
                <dd>{inr(subtotal)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Product discount</dt>
                <dd className="text-primary">−{inr(subtotal - payable)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Delivery</dt>
                <dd>{delivery === 0 ? "Free" : inr(delivery)}</dd>
              </div>
              <div className="mt-4 flex justify-between border-t border-border/60 pt-4 font-display text-xl">
                <dt>Total</dt>
                <dd className="text-primary">{inr(payable + delivery)}</dd>
              </div>
            </dl>
            <Button asChild size="lg" className="mt-7 w-full">
              <Link to="/checkout">Proceed to checkout</Link>
            </Button>
            <Button asChild variant="ghost" className="mt-2 w-full">
              <Link to="/shop">Continue shopping</Link>
            </Button>
          </div>
        </aside>
      </div>
    </Container>
  );
}
