import { createFileRoute } from "@tanstack/react-router";
import { ShopView } from "@/components/shop/ShopView";

export const Route = createFileRoute("/women")({
  head: () => ({
    meta: [
      { title: "Women's Royal Wear — Lehengas & Sarees | Regal Threads" },
      {
        name: "description",
        content:
          "Discover bridal lehengas, silk sarees, anarkalis and designer suits crafted for celebrations.",
      },
      { property: "og:title", content: "Women's Royal Wear | Regal Threads" },
      {
        property: "og:description",
        content: "Bridal lehengas, sarees and anarkalis in hand-worked silk.",
      },
    ],
  }),
  component: () => (
    <ShopView
      title="Women"
      eyebrow="The Maharani Court"
      base={{ gender: "women" }}
      heroImage="/images/women.jpg"
    />
  ),
});
