import { createFileRoute } from "@tanstack/react-router";
import { ShopView } from "@/components/shop/ShopView";

type ShopSearch = { search?: string | undefined; sort?: string | undefined };

export const Route = createFileRoute("/shop")({
  validateSearch: (search: Record<string, unknown>): ShopSearch => ({
    search: typeof search["search"] === "string" ? search["search"].slice(0, 80) : undefined,
    sort: typeof search["sort"] === "string" ? search["sort"] : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Shop All Royal Couture | Regal Threads" },
      {
        name: "description",
        content:
          "Browse the full Regal Threads catalogue — sherwanis, lehengas, sarees and festive couture.",
      },
      { property: "og:title", content: "Shop All | Regal Threads" },
      { property: "og:description", content: "The complete Regal Threads catalogue." },
    ],
  }),
  component: ShopPage,
});

function ShopPage() {
  const { search, sort } = Route.useSearch();
  return (
    <ShopView
      title={search ? `Results for “${search}”` : "The Full House"}
      eyebrow="Shop All"
      description="Every piece in the Regal Threads catalogue."
      base={{ ...(search ? { search } : {}), ...(sort ? { sort } : {}) }}
    />
  );
}
