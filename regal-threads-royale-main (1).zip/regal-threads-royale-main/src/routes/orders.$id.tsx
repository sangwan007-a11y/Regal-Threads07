import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Container } from "@/components/common/Section";
import { EmptyState } from "@/components/common/States";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import { formatDate, inr } from "@/lib/format";
import { OrderTimeline } from "@/components/order/OrderTimeline";

export const Route = createFileRoute("/orders/$id")({
  head: () => ({
    meta: [
      { title: "Order Details | Regal Threads" },
      { name: "description", content: "Track the status of your Regal Threads order." },
      { property: "og:title", content: "Order Details | Regal Threads" },
      { property: "og:description", content: "Your order status and items." },
    ],
  }),
  component: () => (
    <RequireAuth title="Sign in to view this order">
      <OrderPage />
    </RequireAuth>
  ),
});

function OrderPage() {
  const { id } = Route.useParams();
  const { data, isLoading } = useQuery({
    queryKey: ["order", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("orders")
        .select("*, order_items(*)")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  if (isLoading)
    return (
      <Container className="space-y-4 py-16">
        <Skeleton className="h-10 w-56" />
        <Skeleton className="h-64 w-full" />
      </Container>
    );

  if (!data)
    return (
      <Container className="py-24">
        <EmptyState
          title="Order not found"
          action={
            <Button asChild>
              <Link to="/account" search={{ tab: "orders" }}>
                Back to orders
              </Link>
            </Button>
          }
        />
      </Container>
    );

  return (
    <Container className="py-12 md:py-16">
      <p className="eyebrow">Order {data.order_number}</p>
      <h1 className="mt-2 text-4xl md:text-5xl">Thank you for your order</h1>
      <p className="mt-3 text-sm text-muted-foreground">Placed on {formatDate(data.created_at)}</p>

      <div className="mt-10 grid gap-8 lg:grid-cols-[1fr_340px]">
        <div className="space-y-4">
          {(data.order_items ?? []).map((item) => (
            <div key={item.id} className="glass flex gap-4 rounded-sm p-4">
              {item.image_url && (
                <img
                  src={item.image_url}
                  alt={item.product_name}
                  className="aspect-[3/4] w-20 rounded-sm object-cover"
                />
              )}
              <div className="flex-1">
                <h2 className="font-display text-xl">{item.product_name}</h2>
                <p className="mt-1 text-[0.66rem] tracking-[0.18em] uppercase text-muted-foreground">
                  {item.color} · Size {item.size} · Qty {item.quantity}
                </p>
                <p className="mt-2 text-sm">{inr(Number(item.unit_price) * item.quantity)}</p>
              </div>
            </div>
          ))}

          <div className="glass rounded-sm p-6">
            <h2 className="font-display text-xl">Delivery address</h2>
            <p className="mt-3 text-sm text-muted-foreground">
              {data.customer_name}
              <br />
              {data.address_line1}, {data.city}, {data.state} — {data.pincode}
              <br />
              {data.customer_phone}
            </p>
          </div>
        </div>

        <aside className="space-y-6">
          <div className="glass rounded-sm p-6">
            <h2 className="font-display text-xl">Status</h2>
            <div className="mt-5">
              <OrderTimeline status={data.status} />
            </div>
            {data.tracking_info && (
              <p className="mt-5 text-xs text-muted-foreground">{data.tracking_info}</p>
            )}
          </div>

          <div className="glass rounded-sm p-6">
            <h2 className="font-display text-xl">Payment</h2>
            <dl className="mt-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Subtotal</dt>
                <dd>{inr(data.subtotal)}</dd>
              </div>
              {Number(data.coupon_discount) > 0 && (
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Coupon {data.coupon_code}</dt>
                  <dd className="text-primary">−{inr(data.coupon_discount)}</dd>
                </div>
              )}
              <div className="flex justify-between">
                <dt className="text-muted-foreground">Delivery</dt>
                <dd>{Number(data.delivery_fee) === 0 ? "Free" : inr(data.delivery_fee)}</dd>
              </div>
              <div className="flex justify-between border-t border-border/60 pt-3 font-display text-lg">
                <dt>Total</dt>
                <dd className="text-primary">{inr(data.total)}</dd>
              </div>
            </dl>
            <p className="mt-3 text-xs tracking-[0.16em] uppercase text-muted-foreground">
              Cash on delivery
            </p>
          </div>
        </aside>
      </div>
    </Container>
  );
}
