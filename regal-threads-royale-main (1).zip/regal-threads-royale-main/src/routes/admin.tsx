import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { IndianRupee, Package, Plus, ShoppingBag, Trash2, Users } from "lucide-react";
import { Container } from "@/components/common/Section";
import { EmptyState } from "@/components/common/States";
import { ProductCreateDialog } from "@/components/admin/ProductCreateDialog";

import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";

import { formatDate, inr } from "@/lib/format";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin Panel | Regal Threads" },
      { name: "description", content: "Manage orders, products and coupons for Regal Threads." },
      { property: "og:title", content: "Admin Panel | Regal Threads" },
      { property: "og:description", content: "Internal management console." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPanel,
});

type ProductFlag = "is_published" | "is_featured" | "is_bestseller" | "is_new_arrival";

const STATUSES = [
  "placed",
  "confirmed",
  "processing",
  "shipped",
  "out_for_delivery",
  "delivered",
  "cancelled",
] as const;


function StatCards() {
  const { data } = useQuery({
    queryKey: ["admin-stats"],
    queryFn: async () => {
      const [orders, products] = await Promise.all([
        supabase.from("orders").select("total,status"),
        supabase.from("products").select("id", { count: "exact", head: true }),
      ]);
      const rows = orders.data ?? [];
      return {
        orderCount: rows.length,
        revenue: rows
          .filter((o) => o.status !== "cancelled")
          .reduce((s, o) => s + Number(o.total), 0),
        pending: rows.filter((o) => o.status === "placed").length,
        productCount: products.count ?? 0,
      };
    },
  });

  const cards = [
    { icon: ShoppingBag, label: "Orders", value: data?.orderCount ?? "—" },
    { icon: IndianRupee, label: "Revenue", value: data ? inr(data.revenue) : "—" },
    { icon: Users, label: "Awaiting action", value: data?.pending ?? "—" },
    { icon: Package, label: "Products", value: data?.productCount ?? "—" },
  ];

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {cards.map((c) => (
        <div key={c.label} className="glass rounded-sm p-6">
          <c.icon className="size-4 text-primary" />
          <p className="mt-4 font-display text-3xl">{c.value}</p>
          <p className="mt-1 text-[0.62rem] tracking-[0.2em] uppercase text-muted-foreground">
            {c.label}
          </p>
        </div>
      ))}
    </div>
  );
}

function OrdersAdmin() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin-orders"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("orders")
        .select("id,order_number,customer_name,customer_phone,total,status,created_at")
        .order("created_at", { ascending: false })
        .limit(100);
      if (error) throw error;
      return data ?? [];
    },
  });

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase
        .from("orders")
        .update({ status: status as (typeof STATUSES)[number] })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-orders"] });
      qc.invalidateQueries({ queryKey: ["admin-stats"] });
      toast.success("Order updated");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (isLoading) return <Skeleton className="h-64 w-full" />;
  if (!(data ?? []).length) return <EmptyState title="No orders yet" />;

  return (
    <div className="space-y-3">
      {data!.map((o) => (
        <div
          key={o.id}
          className="glass flex flex-wrap items-center justify-between gap-4 rounded-sm p-5"
        >
          <div className="min-w-40">
            <p className="font-display text-xl">{o.order_number}</p>
            <p className="text-xs text-muted-foreground">
              {o.customer_name} · {o.customer_phone}
            </p>
            <p className="text-xs text-muted-foreground">{formatDate(o.created_at)}</p>
          </div>
          <span className="font-medium">{inr(o.total)}</span>
          <Select value={o.status} onValueChange={(v) => updateStatus.mutate({ id: o.id, status: v })}>
            <SelectTrigger className="h-9 w-52 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {STATUSES.map((s) => (
                <SelectItem key={s} value={s}>
                  {s.replace(/_/g, " ")}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      ))}
    </div>
  );
}

function ProductsAdmin() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin-products"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select(
          "id,name,sku,price,gender,is_published,is_featured,is_bestseller,is_new_arrival,product_images(url,sort_order)",
        )
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Array<{
        id: string;
        name: string;
        sku: string;
        price: number;
        gender: string;
        is_published: boolean;
        is_featured: boolean;
        is_bestseller: boolean;
        is_new_arrival: boolean;
        product_images: { url: string; sort_order: number }[];
      }>;
    },
  });

  const toggleFlag = useMutation({
    mutationFn: async ({ id, field, value }: { id: string; field: ProductFlag; value: boolean }) => {
      const { error } = await supabase
        .from("products")
        .update({ [field]: value } as Record<ProductFlag, boolean>)
        .eq("id", id);
      if (error) throw error;
    },

    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-products"] });
      qc.invalidateQueries({ queryKey: ["products"] });
      toast.success("Product updated");
    },
    onError: (e: Error) => {
      toast.error(e.message);
    },
  });

  const removeProduct = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("products").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries();
      toast.success("Product removed");
    },
    onError: (e: Error) => {
      toast.error(e.message);
    },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <p className="text-xs tracking-[0.18em] uppercase text-muted-foreground">
          {(data ?? []).length} products
        </p>
        <ProductCreateDialog />
      </div>

      {isLoading ? (
        <Skeleton className="h-64 w-full" />
      ) : !(data ?? []).length ? (
        <EmptyState title="No products yet" description="Add your first piece to the catalogue." />
      ) : (
        (data ?? []).map((p) => {
          const img = [...(p.product_images ?? [])].sort((a, b) => a.sort_order - b.sort_order)[0];
          return (
            <div
              key={p.id}
              className="glass flex flex-wrap items-center justify-between gap-6 rounded-sm p-5"
            >
              <div className="flex min-w-48 items-center gap-4">
                {img && (
                  <img
                    src={img.url}
                    alt={p.name}
                    loading="lazy"
                    className="size-14 rounded-sm object-cover"
                  />
                )}
                <div>
                  <p className="font-display text-lg">{p.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {p.sku} · {inr(p.price)} · {p.gender}
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-6">
                {[
                  { field: "is_published" as ProductFlag, label: "Live", value: p.is_published },
                  { field: "is_featured" as ProductFlag, label: "Featured", value: p.is_featured },
                  {
                    field: "is_bestseller" as ProductFlag,
                    label: "Bestseller",
                    value: p.is_bestseller,
                  },
                  { field: "is_new_arrival" as ProductFlag, label: "New", value: p.is_new_arrival },
                ].map((f) => (
                  <label
                    key={f.field}
                    className="flex items-center gap-2 text-xs text-muted-foreground"
                  >
                    <Switch
                      checked={f.value}
                      onCheckedChange={(v) => toggleFlag.mutate({ id: p.id, field: f.field, value: v })}
                    />
                    {f.label}
                  </label>
                ))}
                <Button
                  size="icon"
                  variant="ghost"
                  aria-label={`Delete ${p.name}`}
                  onClick={() => {
                    if (confirm(`Remove “${p.name}” from the catalogue?`)) removeProduct.mutate(p.id);
                  }}
                >
                  <Trash2 className="size-4 text-destructive" />
                </Button>
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}

function AddVariantRow({ productId, sku }: { productId: string; sku: string }) {
  const qc = useQueryClient();
  const [size, setSize] = useState("");
  const [color, setColor] = useState("");
  const [stock, setStock] = useState("5");

  const add = useMutation({
    mutationFn: async () => {
      if (!size.trim() || !color.trim()) throw new Error("Size and colour are required");
      const { error } = await supabase.from("product_variants").insert({
        product_id: productId,
        size: size.trim(),
        color: color.trim(),
        stock: Math.max(0, Number(stock) || 0),
        sku: `${sku}-${size.trim()}-${color.trim().slice(0, 2).toUpperCase()}`,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries();
      setSize("");
      setColor("");
      toast.success("Variant added");
    },
    onError: (e: Error) => {
      toast.error(e.message);
    },
  });

  return (
    <div className="mt-4 flex flex-wrap items-center gap-2">
      <Input
        className="h-9 w-24 text-sm"
        placeholder="Size"
        value={size}
        onChange={(e) => setSize(e.target.value)}
      />
      <Input
        className="h-9 w-32 text-sm"
        placeholder="Colour"
        value={color}
        onChange={(e) => setColor(e.target.value)}
      />
      <Input
        className="h-9 w-20 text-sm"
        type="number"
        min={0}
        value={stock}
        onChange={(e) => setStock(e.target.value)}
      />
      <Button size="sm" variant="outline" onClick={() => add.mutate()} disabled={add.isPending}>
        <Plus className="mr-1.5 size-3.5" /> Add variant
      </Button>
    </div>
  );
}

function InventoryAdmin() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin-inventory"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("product_variants")
        .select("id,product_id,size,color,stock,sku,products(name,sku)")
        .order("size");
      if (error) throw error;
      return (data ?? []) as unknown as Array<{
        id: string;
        product_id: string;
        size: string;
        color: string;
        stock: number;
        sku: string | null;
        products: { name: string; sku: string } | null;
      }>;
    },
  });

  const setStock = useMutation({
    mutationFn: async ({ id, stock }: { id: string; stock: number }) => {
      const { error } = await supabase.from("product_variants").update({ stock }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-inventory"] });
      qc.invalidateQueries({ queryKey: ["variants"] });
      toast.success("Stock updated");
    },
    onError: (e: Error) => {
      toast.error(e.message);
    },
  });

  const removeVariant = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("product_variants").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries();
      toast.success("Variant removed");
    },
    onError: (e: Error) => {
      toast.error(e.message);
    },
  });

  if (isLoading) return <Skeleton className="h-64 w-full" />;
  if (!(data ?? []).length) return <EmptyState title="No variants yet" />;

  const groups = new Map<string, typeof data>();
  for (const v of data!) {
    const key = v.products?.name ?? "Unassigned";
    if (!groups.has(key)) groups.set(key, [] as unknown as typeof data);
    groups.get(key)!.push(v);
  }

  const lowCount = data!.filter((v) => v.stock <= 3).length;

  return (
    <div className="space-y-6">
      <p className="text-xs tracking-[0.18em] uppercase text-muted-foreground">
        {data!.length} variants · {lowCount} low or out of stock
      </p>
      {[...groups.entries()].map(([name, variants]) => (
        <div key={name} className="glass rounded-sm p-5">
          <p className="font-display text-xl">{name}</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {variants!.map((v) => (
              <div
                key={v.id}
                className="flex items-center justify-between gap-3 rounded-sm border border-border/60 p-3"
              >
                <div className="min-w-0">
                  <p className="text-sm">
                    {v.size} · {v.color}
                  </p>
                  <p className="truncate text-xs text-muted-foreground">
                    {v.sku ?? v.products?.sku ?? "—"}
                    {v.stock <= 0 ? " · out of stock" : v.stock <= 3 ? " · low stock" : ""}
                  </p>
                </div>
                <div className="flex items-center gap-1">
                  <Input
                    type="number"
                    min={0}
                    className="h-9 w-20 text-sm"
                    defaultValue={v.stock}
                    onBlur={(e) => {
                      const next = Math.max(0, Number(e.target.value));
                      if (Number.isFinite(next) && next !== v.stock)
                        setStock.mutate({ id: v.id, stock: next });
                    }}
                  />
                  <Button
                    size="icon"
                    variant="ghost"
                    aria-label="Remove variant"
                    onClick={() => removeVariant.mutate(v.id)}
                  >
                    <Trash2 className="size-3.5 text-destructive" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
          <AddVariantRow
            productId={variants![0]!.product_id}
            sku={variants![0]!.products?.sku ?? "RT"}
          />
        </div>
      ))}
    </div>
  );
}

function CouponForm() {
  const qc = useQueryClient();
  const [code, setCode] = useState("");
  const [type, setType] = useState("percent");
  const [value, setValue] = useState("10");
  const [minAmount, setMinAmount] = useState("0");

  const add = useMutation({
    mutationFn: async () => {
      if (!code.trim()) throw new Error("Enter a coupon code");
      const { error } = await supabase.from("coupons").insert({
        code: code.trim().toUpperCase(),
        discount_type: type,
        discount_value: Number(value) || 0,
        min_order_amount: Number(minAmount) || 0,
        is_active: true,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-coupons"] });
      setCode("");
      toast.success("Coupon created");
    },
    onError: (e: Error) => {
      toast.error(e.message);
    },
  });

  return (
    <div className="glass flex flex-wrap items-end gap-3 rounded-sm p-5">
      <div>
        <Label htmlFor="c-code" className="text-xs">
          Code
        </Label>
        <Input
          id="c-code"
          className="h-9 w-40 text-sm tracking-widest uppercase"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="ROYAL10"
        />
      </div>
      <div>
        <Label className="text-xs">Type</Label>
        <Select value={type} onValueChange={setType}>
          <SelectTrigger className="h-9 w-32 text-sm">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="percent">Percent</SelectItem>
            <SelectItem value="fixed">Flat ₹</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label htmlFor="c-value" className="text-xs">
          Value
        </Label>
        <Input
          id="c-value"
          type="number"
          className="h-9 w-24 text-sm"
          value={value}
          onChange={(e) => setValue(e.target.value)}
        />
      </div>
      <div>
        <Label htmlFor="c-min" className="text-xs">
          Min order ₹
        </Label>
        <Input
          id="c-min"
          type="number"
          className="h-9 w-28 text-sm"
          value={minAmount}
          onChange={(e) => setMinAmount(e.target.value)}
        />
      </div>
      <Button size="sm" onClick={() => add.mutate()} disabled={add.isPending}>
        <Plus className="mr-1.5 size-3.5" /> Add coupon
      </Button>
    </div>
  );
}

function CouponsAdmin() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin-coupons"],
    queryFn: async () => {
      const { data, error } = await supabase.from("coupons").select("*").order("created_at");
      if (error) throw error;
      return data ?? [];
    },
  });

  const toggleActive = useMutation({
    mutationFn: async ({ id, value }: { id: string; value: boolean }) => {
      const { error } = await supabase.from("coupons").update({ is_active: value }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-coupons"] });
      toast.success("Coupon updated");
    },
    onError: (e: Error) => {
      toast.error(e.message);
    },
  });

  const removeCoupon = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("coupons").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-coupons"] });
      toast.success("Coupon removed");
    },
    onError: (e: Error) => {
      toast.error(e.message);
    },
  });

  return (
    <div className="space-y-4">
      <CouponForm />
      {isLoading ? (
        <Skeleton className="h-40 w-full" />
      ) : !(data ?? []).length ? (
        <EmptyState title="No coupons yet" />
      ) : (
        (data ?? []).map((c) => (
          <div
            key={c.id}
            className="glass flex flex-wrap items-center justify-between gap-4 rounded-sm p-5"
          >
            <div>
              <p className="font-display text-xl tracking-widest">{c.code}</p>
              <p className="text-xs text-muted-foreground">
                {c.discount_type === "percent"
                  ? `${c.discount_value}% off`
                  : `${inr(c.discount_value)} off`}{" "}
                · min {inr(c.min_order_amount)}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 text-xs text-muted-foreground">
                <Switch
                  checked={c.is_active}
                  onCheckedChange={(v) => toggleActive.mutate({ id: c.id, value: v })}
                />
                Active
              </label>
              <Button
                size="icon"
                variant="ghost"
                aria-label={`Delete ${c.code}`}
                onClick={() => removeCoupon.mutate(c.id)}
              >
                <Trash2 className="size-4 text-destructive" />
              </Button>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

function ReviewsAdmin() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin-reviews"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("reviews")
        .select("id,author_name,rating,body,is_approved,created_at")
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data ?? [];
    },
  });

  const setApproved = useMutation({
    mutationFn: async ({ id, value }: { id: string; value: boolean }) => {
      const { error } = await supabase.from("reviews").update({ is_approved: value }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-reviews"] });
      toast.success("Review updated");
    },
  });

  if (isLoading) return <Skeleton className="h-40 w-full" />;
  if (!(data ?? []).length) return <EmptyState title="No reviews yet" />;

  return (
    <div className="space-y-3">
      {data!.map((r) => (
        <div key={r.id} className="glass rounded-sm p-5">
          <div className="flex items-center justify-between gap-4">
            <p className="font-display text-lg">
              {r.author_name} · {r.rating}★
            </p>
            <Button
              size="sm"
              variant={r.is_approved ? "ghost" : "default"}
              onClick={() => setApproved.mutate({ id: r.id, value: !r.is_approved })}
            >
              {r.is_approved ? "Unpublish" : "Approve"}
            </Button>
          </div>
          {r.body && <p className="mt-2 text-sm text-muted-foreground">{r.body}</p>}
        </div>
      ))}
    </div>
  );
}

function AdminPanel() {
  return (
    <Container className="py-12 md:py-16">
      <p className="eyebrow">Royal Court Administration</p>
      <h1 className="mt-2 text-4xl md:text-5xl">Admin Panel</h1>

      <div className="mt-10">
        <StatCards />
      </div>

      <Tabs defaultValue="orders" className="mt-12">
        <TabsList>
          <TabsTrigger value="orders">Orders</TabsTrigger>
          <TabsTrigger value="products">Products</TabsTrigger>
          <TabsTrigger value="inventory">Inventory</TabsTrigger>
          <TabsTrigger value="coupons">Coupons</TabsTrigger>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
        </TabsList>
        <TabsContent value="orders" className="pt-8">
          <OrdersAdmin />
        </TabsContent>
        <TabsContent value="products" className="pt-8">
          <ProductsAdmin />
        </TabsContent>
        <TabsContent value="inventory" className="pt-8">
          <InventoryAdmin />
        </TabsContent>
        <TabsContent value="coupons" className="pt-8">
          <CouponsAdmin />
        </TabsContent>
        <TabsContent value="reviews" className="pt-8">
          <ReviewsAdmin />
        </TabsContent>
      </Tabs>
    </Container>
  );
}
