import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { z } from "zod";
import { Heart, LogOut, MapPin, Package, User as UserIcon } from "lucide-react";
import { Container } from "@/components/common/Section";
import { EmptyState } from "@/components/common/States";
import { RequireAuth } from "@/components/auth/RequireAuth";
import { ProductGrid } from "@/components/product/ProductCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useWishlist } from "@/hooks/useWishlist";
import { formatDate, inr } from "@/lib/format";

type AccountSearch = { tab?: string | undefined };

export const Route = createFileRoute("/account")({
  validateSearch: (search: Record<string, unknown>): AccountSearch => ({
    tab: typeof search["tab"] === "string" ? search["tab"] : undefined,
  }),
  head: () => ({
    meta: [
      { title: "My Account | Regal Threads" },
      {
        name: "description",
        content: "Manage your Regal Threads profile, orders, wishlist and saved addresses.",
      },
      { property: "og:title", content: "My Account | Regal Threads" },
      { property: "og:description", content: "Your royal wardrobe, orders and wishlist." },
    ],
  }),
  component: () => (
    <RequireAuth title="Sign in to view your account">
      <AccountPage />
    </RequireAuth>
  ),
});

const profileSchema = z.object({
  full_name: z.string().trim().min(2, { message: "Enter your name" }).max(100),
  phone: z
    .string()
    .trim()
    .regex(/^[0-9]{10}$/, { message: "Enter a valid 10-digit phone" })
    .or(z.literal("")),
});

function ProfileTab() {
  const { user, isAdmin } = useAuth();
  const qc = useQueryClient();
  const navigate = useNavigate();

  const { data: profile, isLoading } = useQuery({
    queryKey: ["profile", user?.id],
    queryFn: async () => {
      const { data } = await supabase
        .from("profiles")
        .select("full_name,phone,email")
        .eq("id", user!.id)
        .maybeSingle();
      return data;
    },
  });

  const save = useMutation({
    mutationFn: async (form: FormData) => {
      const parsed = profileSchema.safeParse({
        full_name: form.get("full_name"),
        phone: form.get("phone") ?? "",
      });
      if (!parsed.success) throw new Error(parsed.error.issues[0]!.message);
      const { error } = await supabase
        .from("profiles")
        .update({ full_name: parsed.data.full_name, phone: parsed.data.phone || null })
        .eq("id", user!.id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["profile"] });
      toast.success("Profile updated");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const signOut = async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  };

  if (isLoading) return <Skeleton className="h-64 w-full" />;

  return (
    <div className="glass max-w-xl rounded-sm p-7">
      <h2 className="font-display text-2xl">Profile</h2>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate(new FormData(e.currentTarget));
        }}
        className="mt-6 space-y-5"
      >
        <div className="space-y-2">
          <Label htmlFor="full_name">Full name</Label>
          <Input
            id="full_name"
            name="full_name"
            maxLength={100}
            defaultValue={profile?.full_name ?? ""}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="phone">Phone</Label>
          <Input id="phone" name="phone" maxLength={10} defaultValue={profile?.phone ?? ""} />
        </div>
        <div className="space-y-2">
          <Label>Email</Label>
          <Input value={profile?.email ?? user?.email ?? ""} disabled />
        </div>
        <Button type="submit" disabled={save.isPending}>
          Save changes
        </Button>
      </form>

      <div className="mt-8 flex flex-wrap gap-3 border-t border-border/60 pt-6">
        {isAdmin && (
          <Button asChild variant="outline">
            <Link to="/admin">Admin panel</Link>
          </Button>
        )}
        <Button variant="ghost" onClick={signOut}>
          <LogOut className="mr-2 size-4" /> Sign out
        </Button>
      </div>
    </div>
  );
}

function OrdersTab() {
  const { user } = useAuth();
  const { data, isLoading } = useQuery({
    queryKey: ["orders", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("orders")
        .select("id,order_number,total,status,created_at")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  if (isLoading) return <Skeleton className="h-48 w-full" />;
  if (!(data ?? []).length)
    return (
      <EmptyState
        title="No orders yet"
        description="Your royal orders will appear here."
        action={
          <Button asChild>
            <Link to="/shop">Start shopping</Link>
          </Button>
        }
      />
    );

  return (
    <div className="space-y-3">
      {data!.map((o) => (
        <Link
          key={o.id}
          to="/orders/$id"
          params={{ id: o.id }}
          className="glass flex flex-wrap items-center justify-between gap-4 rounded-sm p-5 transition-colors hover:border-primary/40"
        >
          <div>
            <p className="font-display text-xl">{o.order_number}</p>
            <p className="text-xs text-muted-foreground">{formatDate(o.created_at)}</p>
          </div>
          <span className="rounded-full border border-primary/40 px-3 py-1 text-[0.6rem] tracking-[0.18em] uppercase text-primary">
            {o.status.replace(/_/g, " ")}
          </span>
          <span className="font-medium">{inr(o.total)}</span>
        </Link>
      ))}
    </div>
  );
}

function WishlistTab() {
  const { items, isLoading } = useWishlist();
  if (isLoading) return <Skeleton className="h-64 w-full" />;
  if (!items.length)
    return (
      <EmptyState
        title="Your wishlist is empty"
        description="Save the pieces you love and return to them later."
        action={
          <Button asChild>
            <Link to="/shop">Discover pieces</Link>
          </Button>
        }
      />
    );
  return <ProductGrid products={items.map((i) => i.products)} />;
}

const addressSchema = z.object({
  full_name: z.string().trim().min(2).max(100),
  phone: z.string().trim().regex(/^[0-9]{10}$/),
  line1: z.string().trim().min(5).max(250),
  city: z.string().trim().min(2).max(80),
  state: z.string().trim().min(2).max(80),
  pincode: z.string().trim().regex(/^[0-9]{6}$/),
});

function AddressesTab() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["addresses", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("addresses")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  const addAddress = useMutation({
    mutationFn: async (form: FormData) => {
      const parsed = addressSchema.safeParse(Object.fromEntries(form));
      if (!parsed.success) throw new Error("Please check the address details");
      const { error } = await supabase
        .from("addresses")
        .insert({ ...parsed.data, user_id: user!.id });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["addresses"] });
      toast.success("Address saved");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const removeAddress = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("addresses").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["addresses"] }),
  });

  return (
    <div className="grid gap-8 lg:grid-cols-2">
      <div className="space-y-3">
        {isLoading ? (
          <Skeleton className="h-32 w-full" />
        ) : (data ?? []).length === 0 ? (
          <p className="text-sm text-muted-foreground">No saved addresses yet.</p>
        ) : (
          data!.map((a) => (
            <div key={a.id} className="glass rounded-sm p-5">
              <p className="font-display text-lg">{a.full_name}</p>
              <p className="mt-1 text-sm text-muted-foreground">
                {a.line1}, {a.city}, {a.state} — {a.pincode}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">{a.phone}</p>
              <Button
                variant="ghost"
                size="sm"
                className="mt-3"
                onClick={() => removeAddress.mutate(a.id)}
              >
                Remove
              </Button>
            </div>
          ))
        )}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          addAddress.mutate(new FormData(e.currentTarget));
          e.currentTarget.reset();
        }}
        className="glass h-fit rounded-sm p-7"
      >
        <h2 className="font-display text-2xl">Add an address</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <Input name="full_name" placeholder="Full name" required maxLength={100} />
          <Input name="phone" placeholder="Phone" required maxLength={10} />
          <Input
            name="line1"
            placeholder="Address"
            required
            maxLength={250}
            className="sm:col-span-2"
          />
          <Input name="city" placeholder="City" required maxLength={80} />
          <Input name="state" placeholder="State" required maxLength={80} />
          <Input name="pincode" placeholder="Pincode" required maxLength={6} />
        </div>
        <Button type="submit" className="mt-5" disabled={addAddress.isPending}>
          Save address
        </Button>
      </form>
    </div>
  );
}

function AccountPage() {
  const { tab } = Route.useSearch();
  const navigate = useNavigate();

  return (
    <Container className="py-12 md:py-16">
      <p className="eyebrow">Your Court</p>
      <h1 className="mt-2 text-4xl md:text-5xl">My Account</h1>

      <Tabs
        value={tab ?? "profile"}
        onValueChange={(v) => navigate({ to: "/account", search: { tab: v } })}
        className="mt-10"
      >
        <TabsList className="grid w-full max-w-2xl grid-cols-4">
          <TabsTrigger value="profile">
            <UserIcon className="mr-2 size-3.5" /> Profile
          </TabsTrigger>
          <TabsTrigger value="orders">
            <Package className="mr-2 size-3.5" /> Orders
          </TabsTrigger>
          <TabsTrigger value="wishlist">
            <Heart className="mr-2 size-3.5" /> Wishlist
          </TabsTrigger>
          <TabsTrigger value="addresses">
            <MapPin className="mr-2 size-3.5" /> Addresses
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="pt-8">
          <ProfileTab />
        </TabsContent>
        <TabsContent value="orders" className="pt-8">
          <OrdersTab />
        </TabsContent>
        <TabsContent value="wishlist" className="pt-8">
          <WishlistTab />
        </TabsContent>
        <TabsContent value="addresses" className="pt-8">
          <AddressesTab />
        </TabsContent>
      </Tabs>
    </Container>
  );
}
