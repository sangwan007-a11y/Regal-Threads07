import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ShopView } from "@/components/shop/ShopView";
import { collectionsQuery } from "@/lib/catalog";

export const Route = createFileRoute("/collections/$slug")({
  head: ({ params }) => {
    const pretty = params.slug
      .split("-")
      .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
      .join(" ");
    return {
      meta: [
        { title: `${pretty} Collection | Regal Threads` },
        {
          name: "description",
          content: `Shop the ${pretty} collection — handcrafted Indian royal couture from Regal Threads.`,
        },
        { property: "og:title", content: `${pretty} Collection | Regal Threads` },
        { property: "og:description", content: `Handcrafted pieces from the ${pretty} collection.` },
      ],
    };
  },
  component: CollectionPage,
});

function CollectionPage() {
  const { slug } = Route.useParams();
  const { data } = useQuery(collectionsQuery());
  const collection = (data ?? []).find((c) => c.slug === slug);

  return (
    <ShopView
      title={collection?.name ?? "Collection"}
      eyebrow={collection?.tagline ?? "Collection"}
      base={{ collection: slug }}
      heroImage={collection?.image_url ?? "/images/wedding.jpg"}
    />
  );
}
