import { createFileRoute } from "@tanstack/react-router";
import { LegalPage } from "@/components/common/LegalPage";

export const Route = createFileRoute("/return-policy")({
  head: () => ({
    meta: [
      { title: "Return & Exchange Policy | Regal Threads" },
      {
        name: "description",
        content: "Our 7-day return window, exchange process and conditions for Regal Threads orders.",
      },
      { property: "og:title", content: "Return & Exchange Policy | Regal Threads" },
      { property: "og:description", content: "Returns, exchanges and refunds explained." },
    ],
  }),
  component: () => (
    <LegalPage
      eyebrow="Peace of Mind"
      title="Return & Exchange Policy"
      intro="We want every piece to fit like it was made for you."
      sections={[
        {
          heading: "7-day window",
          body: [
            "Returns and exchanges are accepted within 7 days of delivery, provided the piece is unworn, unwashed and carries all original tags and packaging.",
          ],
        },
        {
          heading: "How to request",
          body: [
            "Message us on WhatsApp with your order number and a photo of the piece. We arrange a reverse pickup wherever our courier partners operate.",
          ],
        },
        {
          heading: "Refunds",
          body: [
            "Approved refunds are processed within 7 business days of the returned piece reaching our studio. Cash-on-delivery orders are refunded by bank transfer.",
          ],
        },
        {
          heading: "Non-returnable items",
          body: [
            "Custom-stitched, made-to-measure and personalised embroidery pieces cannot be returned, though we will always try to fix fit issues.",
          ],
        },
      ]}
    />
  ),
});
