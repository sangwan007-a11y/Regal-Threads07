import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { motion } from "motion/react";
import { ArrowRight, Gem, ShieldCheck, Sparkles, Truck } from "lucide-react";
import { Container, Reveal, SectionHeading } from "@/components/common/Section";
import { ProductGrid } from "@/components/product/ProductCard";
import { ProductGridSkeleton } from "@/components/common/States";
import { Stars } from "@/components/common/Stars";
import { Button } from "@/components/ui/button";
import { collectionsQuery, productsQuery, reviewsQuery } from "@/lib/catalog";
import { SITE } from "@/config/site";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Regal Threads — Premium Indian Royal Fashion" },
      {
        name: "description",
        content:
          "Shop handcrafted sherwanis, lehengas, sarees and festive couture for men, women and kids. Dress like royalty.",
      },
      { property: "og:title", content: "Regal Threads — Dress Like Royalty" },
      {
        property: "og:description",
        content: "Premium Indian royal fashion for weddings, festivals and celebrations.",
      },
    ],
  }),
  component: Home,
});

const CATEGORY_TILES = [
  { title: "Men", copy: "Sherwanis & Bandhgalas", image: "/images/men.jpg", to: "/men" as const },
  { title: "Women", copy: "Lehengas & Sarees", image: "/images/women.jpg", to: "/women" as const },
  { title: "Kids", copy: "Little Royals", image: "/images/kids.jpg", to: "/kids" as const },
];

const USPS = [
  { icon: Gem, title: "Handcrafted Couture", copy: "Artisanal embroidery, made to be remembered." },
  { icon: Truck, title: "Free Shipping", copy: `On every order above ₹${SITE.freeDeliveryAbove}.` },
  { icon: ShieldCheck, title: "Easy Returns", copy: "7-day hassle-free return window." },
  { icon: Sparkles, title: "Styling Support", copy: "Personal advice on WhatsApp, any time." },
];

function Hero() {
  return (
    <section className="relative -mt-24 h-[92vh] min-h-[620px] w-full overflow-hidden md:-mt-28">
      <motion.img
        src="/images/hero.jpg"
        alt="Model in an ivory sherwani with gold embroidery"
        initial={{ scale: 1.12 }}
        animate={{ scale: 1 }}
        transition={{ duration: 2.4, ease: [0.22, 1, 0.36, 1] }}
        className="absolute inset-0 size-full object-cover object-center"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-background via-background/70 to-background/20" />
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-background to-transparent" />

      <Container className="relative flex h-full items-center">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
          className="max-w-2xl pt-20"
        >
          <p className="eyebrow">{SITE.motto}</p>
          <h1 className="mt-5 text-5xl leading-[0.95] md:text-8xl">
            Dress Like <span className="gold-text">Royalty</span>
          </h1>
          <p className="mt-6 max-w-lg text-base leading-relaxed text-muted-foreground md:text-lg">
            Regal Threads brings the grandeur of Indian courts to modern celebrations —
            hand-embroidered sherwanis, lehengas and sarees for the moments that matter.
          </p>
          <div className="mt-10 flex flex-wrap gap-3">
            <Button asChild size="lg">
              <Link to="/shop">
                Explore the House <ArrowRight className="ml-2 size-4" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/collections">View Collections</Link>
            </Button>
          </div>
        </motion.div>
      </Container>
    </section>
  );
}

function CategoryTiles() {
  return (
    <Container className="py-20 md:py-28">
      <SectionHeading
        eyebrow="Shop by Court"
        title="Three houses, one legacy"
        description="Curated wardrobes for every member of the family."
      />
      <div className="grid gap-5 md:grid-cols-3">
        {CATEGORY_TILES.map((tile, i) => (
          <Reveal key={tile.title} delay={i * 0.1}>
            <Link
              to={tile.to}
              className="group relative block aspect-[3/4] overflow-hidden rounded-sm"
            >
              <img
                src={tile.image}
                alt={tile.title}
                loading="lazy"
                className="size-full object-cover transition-transform duration-[1200ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
              <div className="glass absolute inset-x-4 bottom-4 rounded-sm px-5 py-4">
                <h3 className="font-display text-2xl">{tile.title}</h3>
                <p className="mt-1 text-[0.68rem] tracking-[0.2em] uppercase text-muted-foreground">
                  {tile.copy}
                </p>
              </div>
            </Link>
          </Reveal>
        ))}
      </div>
    </Container>
  );
}

function FeaturedProducts() {
  const { data, isLoading } = useQuery(productsQuery({ flag: "featured", limit: 8 }));
  return (
    <Container className="py-16 md:py-24">
      <SectionHeading
        eyebrow="The Signature Edit"
        title="Featured couture"
        description="Pieces our atelier is most proud of this season."
        align="left"
        action={
          <Button asChild variant="outline">
            <Link to="/shop">View all</Link>
          </Button>
        }
      />
      {isLoading ? <ProductGridSkeleton /> : <ProductGrid products={data ?? []} />}
    </Container>
  );
}

function EditorialBanner({
  image,
  eyebrow,
  title,
  copy,
  to,
  reverse,
}: {
  image: string;
  eyebrow: string;
  title: string;
  copy: string;
  to: string;
  reverse?: boolean;
}) {
  return (
    <Reveal>
      <div className="relative h-[70vh] min-h-[440px] w-full overflow-hidden">
        <img src={image} alt={title} loading="lazy" className="size-full object-cover" />
        <div
          className={`absolute inset-0 ${reverse ? "bg-gradient-to-l" : "bg-gradient-to-r"} from-background/95 via-background/60 to-transparent`}
        />
        <Container className="absolute inset-0 flex items-center">
          <div className={`max-w-md ${reverse ? "ml-auto text-right" : ""}`}>
            <p className="eyebrow">{eyebrow}</p>
            <h2 className="mt-4 text-4xl md:text-6xl">{title}</h2>
            <p className="mt-5 text-sm leading-relaxed text-muted-foreground md:text-base">{copy}</p>
            <Button asChild className="mt-8">
              <Link to={to}>Discover</Link>
            </Button>
          </div>
        </Container>
      </div>
    </Reveal>
  );
}

function Collections() {
  const { data } = useQuery(collectionsQuery());
  const collections = (data ?? []).slice(0, 6);
  if (!collections.length) return null;
  return (
    <Container className="py-20 md:py-28">
      <SectionHeading
        eyebrow="Curated Worlds"
        title="Our royal collections"
        description="From Maharaja grandeur to festive lightness — every collection tells a story."
      />
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {collections.map((c, i) => (
          <Reveal key={c.id} delay={i * 0.07}>
            <Link
              to="/collections/$slug"
              params={{ slug: c.slug }}
              className="group relative block aspect-[4/3] overflow-hidden rounded-sm"
            >
              <img
                src={c.image_url ?? "/images/wedding.jpg"}
                alt={c.name}
                loading="lazy"
                className="size-full object-cover transition-transform duration-1000 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-background/45 transition-colors group-hover:bg-background/25" />
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <h3 className="font-display text-3xl">{c.name}</h3>
                {c.tagline && (
                  <p className="mt-2 text-[0.66rem] tracking-[0.24em] uppercase text-primary">
                    {c.tagline}
                  </p>
                )}
              </div>
            </Link>
          </Reveal>
        ))}
      </div>
    </Container>
  );
}

function Bestsellers() {
  const { data, isLoading } = useQuery(productsQuery({ flag: "bestseller", limit: 8 }));
  if (!isLoading && !(data ?? []).length) return null;
  return (
    <Container className="py-16 md:py-24">
      <SectionHeading
        eyebrow="Most Adored"
        title="Bestsellers"
        align="left"
        action={
          <Button asChild variant="outline">
            <Link to="/shop" search={{ sort: "popular" }}>
              Shop bestsellers
            </Link>
          </Button>
        }
      />
      {isLoading ? <ProductGridSkeleton count={4} /> : <ProductGrid products={data ?? []} />}
    </Container>
  );
}

function Testimonials() {
  const { data } = useQuery(reviewsQuery());
  const reviews = (data ?? []).slice(0, 3);
  if (!reviews.length) return null;
  return (
    <Container className="py-20 md:py-28">
      <SectionHeading eyebrow="From the Court" title="Loved by our patrons" />
      <div className="grid gap-5 md:grid-cols-3">
        {reviews.map((r, i) => (
          <Reveal key={r.id} delay={i * 0.08}>
            <figure className="glass h-full rounded-sm p-7">
              <Stars rating={Number(r.rating)} />
              <blockquote className="mt-4 font-display text-xl leading-relaxed">
                “{r.body}”
              </blockquote>
              <figcaption className="mt-5 text-[0.66rem] tracking-[0.22em] uppercase text-muted-foreground">
                {r.author_name}
                {r.is_verified && <span className="ml-2 text-primary">Verified</span>}
              </figcaption>
            </figure>
          </Reveal>
        ))}
      </div>
    </Container>
  );
}

function Usps() {
  return (
    <Container className="py-16">
      <div className="grid gap-px overflow-hidden rounded-sm border border-border/60 bg-border/60 sm:grid-cols-2 lg:grid-cols-4">
        {USPS.map((u) => (
          <div key={u.title} className="bg-background px-6 py-8">
            <u.icon className="size-5 text-primary" />
            <h3 className="mt-4 font-display text-xl">{u.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{u.copy}</p>
          </div>
        ))}
      </div>
    </Container>
  );
}

function Home() {
  return (
    <>
      <Hero />
      <CategoryTiles />
      <FeaturedProducts />
      <EditorialBanner
        image="/images/wedding.jpg"
        eyebrow="Wedding Royalty"
        title="For the vows worth remembering"
        copy="Heirloom-grade sherwanis and bridal lehengas, embroidered by hand over weeks."
        to="/collections"
      />
      <Bestsellers />
      <EditorialBanner
        image="/images/festive.jpg"
        eyebrow="Festive Court"
        title="Celebrate in colour"
        copy="Lighter silhouettes, richer palettes — festive couture made for long nights of dancing."
        to="/offers"
        reverse
      />
      <Collections />
      <Testimonials />
      <Usps />
    </>
  );
}
