import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

const STEPS = [
  "placed",
  "confirmed",
  "processing",
  "shipped",
  "out_for_delivery",
  "delivered",
] as const;

export function OrderTimeline({ status }: { status: string }) {
  if (status === "cancelled") {
    return (
      <p className="rounded-sm border border-destructive/40 px-4 py-3 text-sm text-destructive">
        This order was cancelled.
      </p>
    );
  }
  const current = STEPS.indexOf(status as (typeof STEPS)[number]);
  return (
    <ol className="space-y-4">
      {STEPS.map((s, i) => (
        <li key={s} className="flex items-center gap-3">
          <span
            className={cn(
              "grid size-7 place-items-center rounded-full border text-[0.6rem]",
              i <= current
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border text-muted-foreground",
            )}
          >
            {i <= current ? <Check className="size-3.5" /> : i + 1}
          </span>
          <span
            className={cn(
              "text-xs tracking-[0.18em] uppercase",
              i <= current ? "text-foreground" : "text-muted-foreground",
            )}
          >
            {s.replace(/_/g, " ")}
          </span>
        </li>
      ))}
    </ol>
  );
}
