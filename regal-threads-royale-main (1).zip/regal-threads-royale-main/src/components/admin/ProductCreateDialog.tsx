import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { categoriesQuery, collectionsQuery } from "@/lib/catalog";

const IMAGE_OPTIONS = [
  "/images/p-sherwani-burgundy.jpg",
  "/images/p-bandhgala-emerald.jpg",
  "/images/p-nehru-ivory.jpg",
  "/images/p-lehenga-maroon.jpg",
  "/images/p-sharara-ivory.jpg",
  "/images/p-saree-emerald.jpg",
  "/images/p-kids-boy-blue.jpg",
  "/images/p-kids-girl-peach.jpg",
  "/images/men.jpg",
  "/images/women.jpg",
  "/images/kids.jpg",
  "/images/kurta.jpg",
  "/images/anarkali.jpg",
  "/images/saree.jpg",
  "/images/indowestern.jpg",
  "/images/kidsgirl.jpg",
];

const slugify = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");

const list = (s: string) =>
  s
    .split(",")
    .map((x) => x.trim())
    .filter(Boolean);

type Form = {
  name: string;
  sku: string;
  gender: string;
  category_id: string;
  collection_id: string;
  price: string;
  mrp: string;
  fabric: string;
  occasion: string;
  description: string;
  image_url: string;
  sizes: string;
  colors: string;
  stock: string;
};

const EMPTY: Form = {
  name: "",
  sku: "",
  gender: "men",
  category_id: "",
  collection_id: "",
  price: "",
  mrp: "",
  fabric: "",
  occasion: "",
  description: "",
  image_url: IMAGE_OPTIONS[0]!,
  sizes: "S, M, L, XL",
  colors: "Ivory, Gold",
  stock: "10",
};

export function ProductCreateDialog() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Form>(EMPTY);
  const { data: categories } = useQuery(categoriesQuery());
  const { data: collections } = useQuery(collectionsQuery());

  const set = (patch: Partial<Form>) => setForm((f) => ({ ...f, ...patch }));

  const create = useMutation({
    mutationFn: async () => {
      const sizes = list(form.sizes);
      const colors = list(form.colors);
      const price = Number(form.price);
      const mrp = Number(form.mrp || form.price);
      if (!form.name.trim()) throw new Error("Name is required");
      if (!Number.isFinite(price) || price <= 0) throw new Error("Enter a valid price");
      if (!sizes.length || !colors.length) throw new Error("Add at least one size and colour");

      const { data: product, error } = await supabase
        .from("products")
        .insert({
          name: form.name.trim(),
          slug: `${slugify(form.name)}-${Math.random().toString(36).slice(2, 6)}`,
          sku: form.sku.trim() || `RT-${Math.random().toString(36).slice(2, 7).toUpperCase()}`,
          gender: form.gender,
          category_id: form.category_id || null,
          collection_id: form.collection_id || null,
          price,
          mrp,
          fabric: form.fabric.trim() || null,
          occasion: form.occasion.trim() || null,
          description: form.description.trim() || null,
          sizes,
          colors,
          is_published: true,
          is_new_arrival: true,
        })
        .select("id,sku")
        .single();
      if (error) throw error;

      const img = await supabase
        .from("product_images")
        .insert({ product_id: product.id, url: form.image_url, alt: form.name, sort_order: 0 });
      if (img.error) throw img.error;

      const stock = Math.max(0, Number(form.stock) || 0);
      const variants = sizes.flatMap((size) =>
        colors.map((color) => ({
          product_id: product.id,
          size,
          color,
          stock,
          sku: `${product.sku}-${size}-${color.slice(0, 2).toUpperCase()}`,
        })),
      );
      const vr = await supabase.from("product_variants").insert(variants);
      if (vr.error) throw vr.error;
    },
    onSuccess: () => {
      qc.invalidateQueries();
      toast.success("Product added to the catalogue");
      setForm(EMPTY);
      setOpen(false);
    },
    onError: (e: Error) => {
      toast.error(e.message);
    },
  });

  const cats = (categories ?? []).filter((c) => c.gender === form.gender);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm">
          <Plus className="mr-2 size-3.5" /> Add product
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">New product</DialogTitle>
          <DialogDescription>
            It goes live instantly across Men, Women, Kids and Shop.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <Label htmlFor="p-name">Name</Label>
            <Input
              id="p-name"
              value={form.name}
              onChange={(e) => set({ name: e.target.value })}
              placeholder="Burgundy Velvet Sherwani"
            />
          </div>
          <div>
            <Label htmlFor="p-sku">SKU (optional)</Label>
            <Input id="p-sku" value={form.sku} onChange={(e) => set({ sku: e.target.value })} />
          </div>
          <div>
            <Label>Section</Label>
            <Select
              value={form.gender}
              onValueChange={(v) => set({ gender: v, category_id: "" })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="men">Men</SelectItem>
                <SelectItem value="women">Women</SelectItem>
                <SelectItem value="kids">Kids</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Category</Label>
            <Select value={form.category_id} onValueChange={(v) => set({ category_id: v })}>
              <SelectTrigger>
                <SelectValue placeholder="Choose category" />
              </SelectTrigger>
              <SelectContent>
                {cats.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Collection</Label>
            <Select value={form.collection_id} onValueChange={(v) => set({ collection_id: v })}>
              <SelectTrigger>
                <SelectValue placeholder="Optional" />
              </SelectTrigger>
              <SelectContent>
                {(collections ?? []).map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="p-price">Price (₹)</Label>
            <Input
              id="p-price"
              type="number"
              value={form.price}
              onChange={(e) => set({ price: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="p-mrp">MRP (₹)</Label>
            <Input
              id="p-mrp"
              type="number"
              value={form.mrp}
              onChange={(e) => set({ mrp: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="p-fabric">Fabric</Label>
            <Input
              id="p-fabric"
              value={form.fabric}
              onChange={(e) => set({ fabric: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="p-occasion">Occasion</Label>
            <Input
              id="p-occasion"
              value={form.occasion}
              onChange={(e) => set({ occasion: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="p-sizes">Sizes (comma separated)</Label>
            <Input
              id="p-sizes"
              value={form.sizes}
              onChange={(e) => set({ sizes: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="p-colors">Colours (comma separated)</Label>
            <Input
              id="p-colors"
              value={form.colors}
              onChange={(e) => set({ colors: e.target.value })}
            />
          </div>
          <div>
            <Label htmlFor="p-stock">Stock per size/colour</Label>
            <Input
              id="p-stock"
              type="number"
              value={form.stock}
              onChange={(e) => set({ stock: e.target.value })}
            />
          </div>
          <div className="sm:col-span-2">
            <Label htmlFor="p-image">Image URL</Label>
            <Input
              id="p-image"
              value={form.image_url}
              onChange={(e) => set({ image_url: e.target.value })}
            />
            <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
              {IMAGE_OPTIONS.map((src) => (
                <button
                  key={src}
                  type="button"
                  onClick={() => set({ image_url: src })}
                  className={`size-16 shrink-0 overflow-hidden rounded-sm border ${
                    form.image_url === src ? "border-primary" : "border-border"
                  }`}
                >
                  <img src={src} alt="" loading="lazy" className="size-full object-cover" />
                </button>
              ))}
            </div>
          </div>
          <div className="sm:col-span-2">
            <Label htmlFor="p-desc">Description</Label>
            <Textarea
              id="p-desc"
              rows={3}
              value={form.description}
              onChange={(e) => set({ description: e.target.value })}
            />
          </div>
        </div>

        <DialogFooter>
          <Button
            onClick={() => create.mutate()}
            disabled={create.isPending}
            className="w-full sm:w-auto"
          >
            {create.isPending ? "Adding…" : "Add product"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
