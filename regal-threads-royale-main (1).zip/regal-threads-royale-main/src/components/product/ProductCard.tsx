import { Link } from "@tanstack/react-router";
import { Heart } from "lucide-react";
import { motion } from "motion/react";
import { Stars } from "@/components/common/Stars";
import { discountPercent, inr } from "@/lib/format";
import { primaryImage, secondaryImage, type Product } from "@/lib/catalog";
import { useWishlist } from "@/hooks/useWishlist";
import { cn } from "@/lib/utils";

export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  const { ids, toggle } = useWishlist();
  const saved = ids.has(product.id);
  const off = discountPercent(product.mrp, product.price);
  const second = secondaryImage(product);

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.55, delay: Math.min(index, 7) * 0.05, ease: [0.22, 1, 0.36, 1] }}
      className="group relative"
    >
      <Link to="/product/$slug" params={{ slug: product.slug }} className="block">
        <div className="relative aspect-[3/4] overflow-hidden rounded-sm bg-surface">
          <img
            src={primaryImage(product)}
            alt={product.name}
            loading="lazy"
            className={cn(
              "size-full object-cover transition-all duration-700 ease-[cubic-bezier(0.22,1,0.36,1)]",
              second ? "group-hover:opacity-0" : "group-hover:scale-105",
            )}
          />
          {second && (
            <img
              src={second}
              alt=""
              aria-hidden
              loading="lazy"
              className="absolute inset-0 size-full scale-105 object-cover opacity-0 transition-opacity duration-700 group-hover:opacity-100"
            />
          )}

          <div className="pointer-events-none absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-background/85 to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

          <div className="absolute left-3 top-3 flex flex-col gap-1.5">
            {product.is_new_arrival && (
              <span className="glass rounded-full px-2.5 py-1 text-[0.6rem] tracking-[0.18em] uppercase text-primary">
                New
              </span>
            )}
            {product.is_bestseller && (
              <span className="glass rounded-full px-2.5 py-1 text-[0.6rem] tracking-[0.18em] uppercase">
                Bestseller
              </span>
            )}
            {off > 0 && (
              <span className="rounded-full bg-secondary px-2.5 py-1 text-[0.6rem] tracking-[0.18em] uppercase text-secondary-foreground">
                {off}% Off
              </span>
            )}
          </div>

          <span className="pointer-events-none absolute inset-x-4 bottom-4 translate-y-3 rounded-sm border border-primary/40 bg-background/60 py-2 text-center text-[0.62rem] tracking-[0.24em] uppercase text-primary opacity-0 backdrop-blur transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
            View Details
          </span>
        </div>
      </Link>

      <button
        type="button"
        aria-label={saved ? "Remove from wishlist" : "Add to wishlist"}
        onClick={() => toggle.mutate(product.id)}
        className="glass absolute right-3 top-3 grid size-9 place-items-center rounded-full transition-colors hover:text-primary"
      >
        <Heart className={cn("size-4", saved && "fill-primary text-primary")} />
      </button>

      <div className="mt-4 space-y-1.5">
        <Link to="/product/$slug" params={{ slug: product.slug }}>
          <h3 className="line-clamp-1 font-display text-lg leading-snug transition-colors group-hover:text-primary">
            {product.name}
          </h3>
        </Link>
        <p className="text-[0.68rem] tracking-[0.16em] uppercase text-muted-foreground">
          {product.categories?.name ?? product.gender}
        </p>
        <div className="flex items-baseline gap-2">
          <span className="text-sm font-medium">{inr(product.price)}</span>
          {off > 0 && (
            <span className="text-xs text-muted-foreground line-through">{inr(product.mrp)}</span>
          )}
        </div>
        {product.review_count > 0 && (
          <div className="flex items-center gap-2 pt-0.5">
            <Stars rating={Number(product.rating)} size={12} />
            <span className="text-[0.65rem] text-muted-foreground">({product.review_count})</span>
          </div>
        )}
      </div>
    </motion.article>
  );
}

export function ProductGrid({ products }: { products: Product[] }) {
  return (
    <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4 lg:gap-8">
      {products.map((p, i) => (
        <ProductCard key={p.id} product={p} index={i} />
      ))}
    </div>
  );
}
