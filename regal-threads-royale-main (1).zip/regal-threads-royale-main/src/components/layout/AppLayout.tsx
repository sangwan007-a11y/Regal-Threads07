import type { ReactNode } from "react";
import { Header } from "./Header";
import { Footer } from "./Footer";
import { MobileBottomNav } from "./MobileBottomNav";
import { WhatsAppFab } from "./WhatsAppFab";

export function AppLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 pt-24 md:pt-28">{children}</main>
      <Footer />
      <WhatsAppFab />
      <MobileBottomNav />
    </div>
  );
}
