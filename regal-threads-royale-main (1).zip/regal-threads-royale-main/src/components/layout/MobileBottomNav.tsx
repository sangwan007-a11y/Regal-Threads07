import { Link } from "@tanstack/react-router";
import { Heart, Home, LayoutGrid, Search, User } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

export function MobileBottomNav() {
  const { user } = useAuth();
  const item = "flex flex-1 flex-col items-center gap-1 py-3 text-[0.6rem] tracking-[0.18em] uppercase text-muted-foreground transition-colors";
  const active = { className: "text-primary" };

  return (
    <nav className="glass-strong fixed inset-x-0 bottom-0 z-50 flex border-t lg:hidden">
      <Link to="/" className={item} activeProps={active} activeOptions={{ exact: true }}>
        <Home className="size-[18px]" />
        Home
      </Link>
      <Link to="/shop" className={item} activeProps={active}>
        <LayoutGrid className="size-[18px]" />
        Shop
      </Link>
      <Link to="/shop" search={{ search: "" }} className={item}>
        <Search className="size-[18px]" />
        Search
      </Link>
      <Link to="/account" search={{ tab: "wishlist" }} className={item}>
        <Heart className="size-[18px]" />
        Wishlist
      </Link>
      <Link to={user ? "/account" : "/auth"} className={item} activeProps={active}>
        <User className="size-[18px]" />
        Account
      </Link>
    </nav>
  );
}
