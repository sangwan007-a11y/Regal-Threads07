import { Link } from "@tanstack/react-router";
import { Facebook, Instagram, MessageCircle } from "lucide-react";
import { Container } from "@/components/common/Section";
import { SITE } from "@/config/site";
import { whatsappEnquiryUrl } from "@/lib/whatsapp";

const SHOP = [
  { label: "Men", to: "/men" },
  { label: "Women", to: "/women" },
  { label: "Kids", to: "/kids" },
  { label: "Collections", to: "/collections" },
  { label: "New Arrivals", to: "/new-arrivals" },
  { label: "Offers", to: "/offers" },
] as const;

const HELP = [
  { label: "About", to: "/about" },
  { label: "Contact", to: "/contact" },
  { label: "Track Order", to: "/track" },
  { label: "Shipping Policy", to: "/shipping-policy" },
  { label: "Return Policy", to: "/return-policy" },
  { label: "Privacy Policy", to: "/privacy-policy" },
  { label: "Terms & Conditions", to: "/terms" },
] as const;

export function Footer() {
  return (
    <footer className="mt-24 border-t border-border/60 bg-charcoal/40 pb-24 pt-16 lg:pb-16">
      <Container>
        <div className="rounded-2xl p-6 md:p-8 glass">
          <div className="grid gap-12 md:grid-cols-[1.4fr_1fr_1fr]">
            <div>
              <h3 className="font-display text-2xl tracking-[0.16em]">REGAL THREADS</h3>
              <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
                Where every occasion deserves a royal entrance. Handcrafted Indian couture for men,
                women and kids.
              </p>
              <div className="mt-6 flex gap-3">
                <a
                  href={SITE.instagram}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="Instagram"
                  className="glass grid size-10 place-items-center rounded-full transition-colors hover:text-primary"
                >
                  <Instagram className="size-4" />
                </a>
                <a
                  href={SITE.facebook}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="Facebook"
                  className="glass grid size-10 place-items-center rounded-full transition-colors hover:text-primary"
                >
                  <Facebook className="size-4" />
                </a>
                <a
                  href={whatsappEnquiryUrl("Hello Regal Threads, I'd like to know more.")}
                  target="_blank"
                  rel="noreferrer"
                  aria-label="WhatsApp"
                  className="glass grid size-10 place-items-center rounded-full transition-colors hover:text-primary"
                >
                  <MessageCircle className="size-4" />
                </a>
              </div>
            </div>

            <div>
              <p className="eyebrow mb-5">Shop</p>
              <ul className="space-y-3 text-sm text-muted-foreground">
                {SHOP.map((l) => (
                  <li key={l.to}>
                    <Link to={l.to} className="transition-colors hover:text-primary">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <p className="eyebrow mb-5">House</p>
              <ul className="space-y-3 text-sm text-muted-foreground">
                {HELP.map((l) => (
                  <li key={l.to}>
                    <Link to={l.to} className="transition-colors hover:text-primary">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mt-14 flex flex-col gap-3 border-t border-border/60 pt-6 text-xs text-muted-foreground md:flex-row md:items-center md:justify-between">
            <p>© {new Date().getFullYear()} Regal Threads. All rights reserved.</p>
            <p className="tracking-[0.2em] uppercase">Don't Just Attend. Rule It.</p>
          </div>
        </div>
      </Container>
    </footer>
  );
}
