import { MessageCircle } from "lucide-react";
import { whatsappEnquiryUrl } from "@/lib/whatsapp";

export function WhatsAppFab() {
  return (
    <a
      href={whatsappEnquiryUrl("Hello Regal Threads, I need help choosing an outfit.")}
      target="_blank"
      rel="noreferrer"
      aria-label="Chat on WhatsApp"
      className="glass-strong royal-shadow fixed bottom-20 right-5 z-40 grid size-12 place-items-center rounded-full text-primary transition-transform hover:scale-105 lg:bottom-8 lg:right-8"
    >
      <MessageCircle className="size-5" />
    </a>
  );
}
