import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { Heart, Menu, Search, ShoppingBag, User } from "lucide-react";
import { motion } from "motion/react";
import { Logo } from "@/components/brand/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Dialog, DialogContent, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useAuth } from "@/hooks/useAuth";
import { useCart } from "@/hooks/useCart";
import { useWishlist } from "@/hooks/useWishlist";
import { cn } from "@/lib/utils";

const NAV = [
  { label: "Men", to: "/men" },
  { label: "Women", to: "/women" },
  { label: "Kids", to: "/kids" },
  { label: "Collections", to: "/collections" },
  { label: "New Arrivals", to: "/new-arrivals" },
  { label: "Offers", to: "/offers" },
] as const;

function SearchBox({ onDone }: { onDone?: () => void }) {
  const [term, setTerm] = useState("");
  const navigate = useNavigate();
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        const q = term.trim();
        if (!q) return;
        navigate({ to: "/shop", search: { search: q } });
        onDone?.();
      }}
      className="flex gap-2"
    >
      <Input
        autoFocus
        value={term}
        onChange={(e) => setTerm(e.target.value)}
        maxLength={80}
        placeholder="Search sherwanis, lehengas, sarees…"
        className="h-11"
      />
      <Button type="submit" className="h-11">
        Search
      </Button>
    </form>
  );
}

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const { user, isAdmin } = useAuth();
  const { count } = useCart();
  const { items: wishlist } = useWishlist();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -24, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className={cn(
        "glass-strong fixed inset-x-0 top-0 z-50 border-b transition-all duration-500",
        scrolled ? "py-2" : "py-4",
      )}
    >
      <div className="mx-auto flex w-full max-w-7xl items-center justify-between gap-4 rounded-2xl px-5 py-3 md:px-8 md:py-4 glass">
        <div className="flex items-center gap-3">
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Open menu">
                <Menu />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="glass-strong w-[85vw] max-w-sm border-r">
              <SheetTitle className="sr-only">Menu</SheetTitle>
              <div className="px-6 pt-6">
                <Logo compact />
              </div>
              <nav className="mt-8 flex flex-col px-6">
                {NAV.map((item) => (
                  <Link
                    key={item.to}
                    to={item.to}
                    onClick={() => setMenuOpen(false)}
                    className="border-b border-border/60 py-4 font-display text-2xl tracking-wide transition-colors hover:text-primary"
                  >
                    {item.label}
                  </Link>
                ))}
                <Link
                  to="/track"
                  onClick={() => setMenuOpen(false)}
                  className="py-4 text-sm tracking-[0.2em] uppercase text-muted-foreground"
                >
                  Track Order
                </Link>
                {isAdmin && (
                  <Link
                    to="/admin"
                    onClick={() => setMenuOpen(false)}
                    className="text-sm tracking-[0.2em] uppercase text-primary"
                  >
                    Admin
                  </Link>
                )}
              </nav>
            </SheetContent>
          </Sheet>
          <Logo compact={scrolled} className="hidden sm:flex" />
          <Logo compact className="sm:hidden" />
        </div>

        <nav className="hidden items-center gap-8 lg:flex">
          {NAV.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="text-[0.72rem] tracking-[0.24em] uppercase text-muted-foreground transition-colors hover:text-primary"
              activeProps={{ className: "text-primary" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-0.5">
          <Dialog open={searchOpen} onOpenChange={setSearchOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Search">
                <Search className="size-[18px]" />
              </Button>
            </DialogTrigger>
            <DialogContent className="glass-strong top-32 translate-y-0">
              <DialogTitle className="font-display text-2xl">Search the house</DialogTitle>
              <SearchBox onDone={() => setSearchOpen(false)} />
            </DialogContent>
          </Dialog>

          <Button variant="ghost" size="icon" asChild className="relative hidden sm:inline-flex">
            <Link to="/account" search={{ tab: "wishlist" }} aria-label="Wishlist">
              <Heart className="size-[18px]" />
              {wishlist.length > 0 && (
                <span className="absolute right-1 top-1 size-1.5 rounded-full bg-primary" />
              )}
            </Link>
          </Button>

          <Button variant="ghost" size="icon" asChild className="hidden sm:inline-flex">
            <Link to={user ? "/account" : "/auth"} aria-label="Account">
              <User className="size-[18px]" />
            </Link>
          </Button>

          <Button variant="ghost" size="icon" asChild className="relative">
            <Link to="/cart" aria-label="Cart">
              <ShoppingBag className="size-[18px]" />
              {count > 0 && (
                <span className="absolute -right-0.5 -top-0.5 grid size-4 place-items-center rounded-full bg-primary text-[0.6rem] font-medium text-primary-foreground">
                  {count}
                </span>
              )}
            </Link>
          </Button>
        </div>
      </div>
    </motion.header>
  );
}
