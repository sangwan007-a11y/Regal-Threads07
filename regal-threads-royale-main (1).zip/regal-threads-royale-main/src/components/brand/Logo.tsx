import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

export function Logo({ className, compact }: { className?: string; compact?: boolean }) {
  return (
    <Link to="/" className={cn("group flex items-center gap-3", className)} aria-label="Regal Threads home">
      <span
        aria-hidden
        className="grid size-9 place-items-center rounded-full border border-primary/40 font-display text-lg text-primary transition-colors group-hover:border-primary"
      >
        R
      </span>
      <span className="leading-none">
        <span
          className={cn(
            "block font-display tracking-[0.18em] text-foreground transition-all",
            compact ? "text-lg" : "text-xl",
          )}
        >
          REGAL THREADS
        </span>
        {!compact && (
          <span className="mt-1 block text-[0.55rem] tracking-[0.34em] text-muted-foreground">
            ROYAL INDIAN COUTURE
          </span>
        )}
      </span>
    </Link>
  );
}
