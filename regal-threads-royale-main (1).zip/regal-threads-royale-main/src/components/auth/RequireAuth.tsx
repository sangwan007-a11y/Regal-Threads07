import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { Container } from "@/components/common/Section";
import { EmptyState } from "@/components/common/States";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAuth } from "@/hooks/useAuth";

export function RequireAuth({ children, title }: { children: ReactNode; title?: string }) {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <Container className="space-y-4 py-20">
        <Skeleton className="h-10 w-64" />
        <Skeleton className="h-40 w-full" />
      </Container>
    );
  }

  if (!user) {
    return (
      <Container className="py-24">
        <EmptyState
          title={title ?? "Sign in to continue"}
          description="Create an account or sign in to access your royal wardrobe."
          action={
            <Button asChild>
              <Link to="/auth">Sign in</Link>
            </Button>
          }
        />
      </Container>
    );
  }

  return <>{children}</>;
}
