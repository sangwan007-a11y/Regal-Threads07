import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { SlidersHorizontal, X } from "lucide-react";
import { Container } from "@/components/common/Section";
import { ProductGrid } from "@/components/product/ProductCard";
import { EmptyState, ErrorState, ProductGridSkeleton } from "@/components/common/States";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { categoriesQuery, productsQuery, type ProductFilters } from "@/lib/catalog";
import { SIZES } from "@/config/site";
import { inr } from "@/lib/format";
import { cn } from "@/lib/utils";

const SORTS = [
  { value: "featured", label: "Featured" },
  { value: "newest", label: "Newest first" },
  { value: "price-asc", label: "Price: low to high" },
  { value: "price-desc", label: "Price: high to low" },
  { value: "rating", label: "Top rated" },
  { value: "discount", label: "Biggest discount" },
  { value: "popular", label: "Most popular" },
];

const COLORS = [
  "Ivory",
  "Gold",
  "Maroon",
  "Emerald",
  "Black",
  "Navy",
  "Peach",
  "Wine",
  "Beige",
  "Red",
];

const MAX_PRICE = 100000;

type LocalFilters = {
  category?: string | undefined;
  sizes: string[];
  colors: string[];
  price: [number, number];
  minDiscount?: number | undefined;
  sort: string;
};

function FilterPanel({
  value,
  onChange,
  gender,
}: {
  value: LocalFilters;
  onChange: (next: LocalFilters) => void;
  gender?: string | undefined;
}) {
  const { data: categories } = useQuery(categoriesQuery());
  const cats = (categories ?? []).filter((c) => !gender || c.gender === gender);

  const toggleIn = (list: string[], item: string) =>
    list.includes(item) ? list.filter((i) => i !== item) : [...list, item];

  return (
    <div className="space-y-8">
      {cats.length > 0 && (
        <div>
          <p className="eyebrow mb-4">Category</p>
          <div className="space-y-2.5">
            {cats.map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() =>
                  onChange({ ...value, category: value.category === c.slug ? undefined : c.slug })
                }
                className={cn(
                  "block text-left text-sm transition-colors hover:text-primary",
                  value.category === c.slug ? "text-primary" : "text-muted-foreground",
                )}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>
      )}

      <div>
        <p className="eyebrow mb-4">Size</p>
        <div className="flex flex-wrap gap-2">
          {SIZES.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => onChange({ ...value, sizes: toggleIn(value.sizes, s) })}
              className={cn(
                "min-w-11 rounded-sm border px-3 py-2 text-xs tracking-widest transition-colors",
                value.sizes.includes(s)
                  ? "border-primary text-primary"
                  : "border-border text-muted-foreground hover:border-primary/50",
              )}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="eyebrow mb-4">Colour</p>
        <div className="space-y-2.5">
          {COLORS.map((c) => (
            <div key={c} className="flex items-center gap-2.5">
              <Checkbox
                id={`color-${c}`}
                checked={value.colors.includes(c)}
                onCheckedChange={() => onChange({ ...value, colors: toggleIn(value.colors, c) })}
              />
              <Label htmlFor={`color-${c}`} className="text-sm font-normal text-muted-foreground">
                {c}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <div>
        <p className="eyebrow mb-4">Price</p>
        <Slider
          value={value.price}
          min={0}
          max={MAX_PRICE}
          step={1000}
          onValueChange={(v) => onChange({ ...value, price: [v[0]!, v[1]!] as [number, number] })}
        />
        <div className="mt-3 flex justify-between text-xs text-muted-foreground">
          <span>{inr(value.price[0])}</span>
          <span>{inr(value.price[1])}</span>
        </div>
      </div>

      <div>
        <p className="eyebrow mb-4">Discount</p>
        <div className="flex flex-wrap gap-2">
          {[10, 20, 30, 50].map((d) => (
            <button
              key={d}
              type="button"
              onClick={() =>
                onChange({ ...value, minDiscount: value.minDiscount === d ? undefined : d })
              }
              className={cn(
                "rounded-sm border px-3 py-2 text-xs transition-colors",
                value.minDiscount === d
                  ? "border-primary text-primary"
                  : "border-border text-muted-foreground hover:border-primary/50",
              )}
            >
              {d}%+
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export function ShopView({
  title,
  eyebrow,
  description,
  base,
  heroImage,
}: {
  title: string;
  eyebrow?: string | undefined;
  description?: string | undefined;
  base: ProductFilters;
  heroImage?: string | undefined;
}) {
  const [filters, setFilters] = useState<LocalFilters>({
    sizes: [],
    colors: [],
    price: [0, MAX_PRICE],
    sort: "featured",
  });

  const merged: ProductFilters = useMemo(
    () => ({
      ...base,
      category: filters.category ?? base.category,
      sizes: filters.sizes.length ? filters.sizes : undefined,
      colors: filters.colors.length ? filters.colors : undefined,
      minPrice: filters.price[0] || undefined,
      maxPrice: filters.price[1] < MAX_PRICE ? filters.price[1] : undefined,
      minDiscount: filters.minDiscount,
      sort: filters.sort,
    }),
    [base, filters],
  );

  const { data, isLoading, isError, refetch } = useQuery(productsQuery(merged));
  const products = data ?? [];
  const activeCount =
    filters.sizes.length +
    filters.colors.length +
    (filters.category ? 1 : 0) +
    (filters.minDiscount ? 1 : 0);

  const reset = () =>
    setFilters({ sizes: [], colors: [], price: [0, MAX_PRICE], sort: filters.sort });

  return (
    <>
      {heroImage && (
        <div className="relative h-[38vh] min-h-[260px] w-full overflow-hidden">
          <img src={heroImage} alt={title} className="size-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-background/20" />
          <Container className="absolute inset-0 flex flex-col justify-end pb-8">
            {eyebrow && <p className="eyebrow">{eyebrow}</p>}
            <h1 className="mt-2 text-4xl md:text-6xl">{title}</h1>
          </Container>
        </div>
      )}

      <Container className="py-12 md:py-16">
        {!heroImage && (
          <div className="mb-10">
            {eyebrow && <p className="eyebrow">{eyebrow}</p>}
            <h1 className="mt-2 text-4xl md:text-5xl">{title}</h1>
            {description && (
              <p className="mt-3 max-w-xl text-sm text-muted-foreground">{description}</p>
            )}
          </div>
        )}

        <div className="grid gap-10 lg:grid-cols-[240px_1fr]">
          <aside className="hidden lg:block">
            <div className="sticky top-28">
              <div className="mb-6 flex items-center justify-between">
                <p className="font-display text-xl">Filters</p>
                {activeCount > 0 && (
                  <button
                    type="button"
                    onClick={reset}
                    className="text-xs text-muted-foreground underline-offset-4 hover:text-primary hover:underline"
                  >
                    Clear
                  </button>
                )}
              </div>
              <FilterPanel value={filters} onChange={setFilters} gender={base.gender} />
            </div>
          </aside>

          <div>
            <div className="mb-8 flex items-center justify-between gap-3">
              <p className="text-xs tracking-[0.18em] uppercase text-muted-foreground">
                {isLoading ? "Loading" : `${products.length} pieces`}
              </p>
              <div className="flex items-center gap-2">
                <Sheet>
                  <SheetTrigger asChild>
                    <Button variant="outline" size="sm" className="lg:hidden">
                      <SlidersHorizontal className="mr-2 size-3.5" />
                      Filters{activeCount ? ` (${activeCount})` : ""}
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-[88vw] max-w-sm overflow-y-auto">
                    <SheetTitle className="px-6 pt-6 font-display text-2xl">Filters</SheetTitle>
                    <div className="px-6 pb-16 pt-6">
                      <FilterPanel value={filters} onChange={setFilters} gender={base.gender} />
                      <Button variant="outline" className="mt-8 w-full" onClick={reset}>
                        <X className="mr-2 size-3.5" /> Clear all
                      </Button>
                    </div>
                  </SheetContent>
                </Sheet>

                <Select
                  value={filters.sort}
                  onValueChange={(v) => setFilters({ ...filters, sort: v })}
                >
                  <SelectTrigger className="h-9 w-[170px] text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SORTS.map((s) => (
                      <SelectItem key={s.value} value={s.value}>
                        {s.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {isError ? (
              <ErrorState onRetry={() => refetch()} />
            ) : isLoading ? (
              <ProductGridSkeleton />
            ) : products.length === 0 ? (
              <EmptyState
                title="No pieces match your court"
                description="Try relaxing a filter or two."
                action={
                  <Button variant="outline" onClick={reset}>
                    Clear filters
                  </Button>
                }
              />
            ) : (
              <ProductGrid products={products} />
            )}
          </div>
        </div>
      </Container>
    </>
  );
}
