export const SITE = {
  name: "Regal Threads",
  tagline: "Dress Like Royalty.",
  description:
    "Regal Threads — Premium Indian Royal Fashion. Sherwanis, lehengas, sarees and festive couture for men, women and kids.",
  motto: "Don't Just Attend. Rule It.",
  /** Configurable WhatsApp business number (digits only, with country code). */
  whatsappNumber: (import.meta.env["VITE_WHATSAPP_NUMBER"] as string | undefined) ?? "919000000000",
  email: "care@regalthreads.in",
  instagram: "https://instagram.com",
  facebook: "https://facebook.com",
  freeDeliveryAbove: 4999,
  deliveryFee: 199,
} as const;

export const SIZES = ["S", "M", "L", "XL", "XXL"] as const;

export const GENDER_CATEGORIES: Record<string, string[]> = {
  men: [
    "Sherwanis",
    "Kurta Sets",
    "Indo-Western",
    "Bandhgala",
    "Nehru Jackets",
    "Wedding Collection",
    "Festive Collection",
    "Maharaja Collection",
  ],
  women: [
    "Lehengas",
    "Sarees",
    "Anarkali",
    "Sharara",
    "Gharara",
    "Designer Suits",
    "Wedding Collection",
    "Festive Collection",
    "Maharani Collection",
  ],
  kids: [
    "Kids Sherwani",
    "Kids Kurta Sets",
    "Kids Lehengas",
    "Kids Indo-Western",
    "Little Maharaja",
    "Little Maharani",
    "Wedding Collection",
    "Festive Collection",
  ],
};
