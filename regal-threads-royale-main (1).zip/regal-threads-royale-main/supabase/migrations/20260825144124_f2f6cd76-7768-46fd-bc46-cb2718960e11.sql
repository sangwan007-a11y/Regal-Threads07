GRANT SELECT, INSERT, UPDATE, DELETE ON public.orders TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.order_items TO anon;
GRANT ALL ON public.orders TO service_role;
GRANT ALL ON public.order_items TO service_role;

CREATE POLICY "open admin orders" ON public.orders FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "open admin order items" ON public.order_items FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);