-- 1. Open write access for the public admin panel
GRANT SELECT, INSERT, UPDATE, DELETE ON public.products TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.product_images TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.product_variants TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.coupons TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.categories TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.collections TO anon, authenticated;

CREATE POLICY "open admin products" ON public.products FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "open admin product_images" ON public.product_images FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "open admin product_variants" ON public.product_variants FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "open admin coupons" ON public.coupons FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

-- 2. Realtime
ALTER TABLE public.products REPLICA IDENTITY FULL;
ALTER TABLE public.product_images REPLICA IDENTITY FULL;
ALTER TABLE public.product_variants REPLICA IDENTITY FULL;
ALTER TABLE public.coupons REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.products;
ALTER PUBLICATION supabase_realtime ADD TABLE public.product_images;
ALTER PUBLICATION supabase_realtime ADD TABLE public.product_variants;
ALTER PUBLICATION supabase_realtime ADD TABLE public.coupons;

-- 3. Seed new products
WITH c AS (SELECT slug, id FROM public.categories),
     col AS (SELECT slug, id FROM public.collections),
new_products AS (
  INSERT INTO public.products (slug, name, sku, description, gender, category_id, collection_id, price, mrp, fabric, occasion, care, colors, sizes, rating, review_count, is_featured, is_bestseller, is_new_arrival)
  VALUES
  ('burgundy-velvet-sherwani','Burgundy Velvet Sherwani','RT-M-201','Hand-embroidered zardozi on plush velvet, cut for the groom who owns the room.','men',(SELECT id FROM c WHERE slug='sherwanis'),(SELECT id FROM col WHERE slug='wedding-royalty'),48999,64999,'Velvet','Wedding','Dry clean only',ARRAY['Maroon','Wine'],ARRAY['S','M','L','XL','XXL'],4.8,42,true,true,true),
  ('emerald-silk-bandhgala','Emerald Silk Bandhgala','RT-M-202','Raw silk bandhgala with antique gold buttons — sharp, modern, unmistakably royal.','men',(SELECT id FROM c WHERE slug='bandhgala'),(SELECT id FROM col WHERE slug='maharaja'),27999,34999,'Raw Silk','Reception','Dry clean only',ARRAY['Emerald','Black'],ARRAY['S','M','L','XL'],4.6,28,false,true,true),
  ('ivory-nehru-jacket-set','Ivory Kurta with Black Nehru Jacket','RT-M-203','Cream cotton-silk kurta paired with a resham-worked black Nehru jacket.','men',(SELECT id FROM c WHERE slug='nehru-jackets'),(SELECT id FROM col WHERE slug='festive-royalty'),15999,21999,'Cotton Silk','Festive','Dry clean recommended',ARRAY['Ivory','Black'],ARRAY['S','M','L','XL','XXL'],4.5,19,true,false,true),
  ('maroon-bridal-lehenga','Maroon Bridal Lehenga','RT-W-201','Gota patti and zari across a full flared maroon lehenga with net dupatta.','women',(SELECT id FROM c WHERE slug='lehengas'),(SELECT id FROM col WHERE slug='wedding-royalty'),74999,99999,'Velvet','Wedding','Dry clean only',ARRAY['Maroon','Red'],ARRAY['XS','S','M','L','XL'],4.9,66,true,true,true),
  ('ivory-gold-sharara','Ivory Gold Organza Sharara','RT-W-202','Featherlight organza sharara with pearl and sequin hand-work.','women',(SELECT id FROM c WHERE slug='sharara'),(SELECT id FROM col WHERE slug='maharani'),32999,44999,'Organza','Sangeet','Dry clean only',ARRAY['Ivory','Gold','Beige'],ARRAY['XS','S','M','L','XL'],4.7,31,false,true,true),
  ('emerald-banarasi-saree','Emerald Banarasi Silk Saree','RT-W-203','Pure Banarasi silk with a hand-woven antique zari border.','women',(SELECT id FROM c WHERE slug='sarees'),(SELECT id FROM col WHERE slug='festive-royalty'),24999,32999,'Banarasi Silk','Festive','Dry clean only',ARRAY['Emerald','Gold'],ARRAY['Free'],4.6,24,true,false,true),
  ('kids-royal-blue-kurta','Little Royal Blue Kurta Set','RT-K-201','Silk kurta with gold buttons and a matching churidar for the little prince.','kids',(SELECT id FROM c WHERE slug='kids-kurta-sets'),(SELECT id FROM col WHERE slug='little-maharaja'),6999,9999,'Art Silk','Festive','Gentle dry clean',ARRAY['Navy','Gold'],ARRAY['2-3Y','4-5Y','6-7Y','8-9Y','10-11Y'],4.5,14,true,false,true),
  ('kids-peach-lehenga','Little Peach Gold Lehenga','RT-K-202','Peach net lehenga with gold thread work and a soft dupatta.','kids',(SELECT id FROM c WHERE slug='kids-lehengas'),(SELECT id FROM col WHERE slug='little-maharani'),8499,11999,'Net','Wedding','Gentle dry clean',ARRAY['Peach','Gold'],ARRAY['2-3Y','4-5Y','6-7Y','8-9Y','10-11Y'],4.7,17,false,true,true)
  RETURNING id, slug, name, sizes, colors
)
INSERT INTO public.product_images (product_id, url, alt, sort_order)
SELECT np.id, i.url, np.name, i.sort_order
FROM new_products np
JOIN (VALUES
  ('burgundy-velvet-sherwani','/images/p-sherwani-burgundy.jpg',0),
  ('burgundy-velvet-sherwani','/images/men.jpg',1),
  ('emerald-silk-bandhgala','/images/p-bandhgala-emerald.jpg',0),
  ('emerald-silk-bandhgala','/images/indowestern.jpg',1),
  ('ivory-nehru-jacket-set','/images/p-nehru-ivory.jpg',0),
  ('ivory-nehru-jacket-set','/images/kurta.jpg',1),
  ('maroon-bridal-lehenga','/images/p-lehenga-maroon.jpg',0),
  ('maroon-bridal-lehenga','/images/women.jpg',1),
  ('ivory-gold-sharara','/images/p-sharara-ivory.jpg',0),
  ('ivory-gold-sharara','/images/anarkali.jpg',1),
  ('emerald-banarasi-saree','/images/p-saree-emerald.jpg',0),
  ('emerald-banarasi-saree','/images/saree.jpg',1),
  ('kids-royal-blue-kurta','/images/p-kids-boy-blue.jpg',0),
  ('kids-royal-blue-kurta','/images/kids.jpg',1),
  ('kids-peach-lehenga','/images/p-kids-girl-peach.jpg',0),
  ('kids-peach-lehenga','/images/kidsgirl.jpg',1)
) AS i(slug,url,sort_order) ON i.slug = np.slug;

-- 4. Variants for the new products
INSERT INTO public.product_variants (product_id, size, color, stock, sku)
SELECT p.id, s.size, c.color, 4 + floor(random()*10)::int, p.sku || '-' || s.size || '-' || upper(left(c.color,2))
FROM public.products p
CROSS JOIN LATERAL unnest(p.sizes) AS s(size)
CROSS JOIN LATERAL unnest(p.colors) AS c(color)
WHERE p.sku IN ('RT-M-201','RT-M-202','RT-M-203','RT-W-201','RT-W-202','RT-W-203','RT-K-201','RT-K-202');

-- 5. Extra coupons
INSERT INTO public.coupons (code, discount_type, discount_value, min_order_amount, max_discount, is_active)
VALUES ('WEDDING20','percent',20,50000,15000,true),
       ('FLAT2000','fixed',2000,15000,NULL,true)
ON CONFLICT DO NOTHING;