INSERT INTO public.categories (slug, name, gender, image_url, sort_order) VALUES
('sherwanis','Sherwanis','men','/images/hero.jpg',1),
('kurta-sets','Kurta Sets','men','/images/kurta.jpg',2),
('indo-western','Indo-Western','men','/images/indowestern.jpg',3),
('bandhgala','Bandhgala','men','/images/men.jpg',4),
('nehru-jackets','Nehru Jackets','men','/images/men.jpg',5),
('lehengas','Lehengas','women','/images/women.jpg',1),
('sarees','Sarees','women','/images/saree.jpg',2),
('anarkali','Anarkali','women','/images/anarkali.jpg',3),
('sharara','Sharara','women','/images/women.jpg',4),
('gharara','Gharara','women','/images/saree.jpg',5),
('designer-suits','Designer Suits','women','/images/anarkali.jpg',6),
('kids-sherwani','Kids Sherwani','kids','/images/kids.jpg',1),
('kids-kurta-sets','Kids Kurta Sets','kids','/images/kids.jpg',2),
('kids-lehengas','Kids Lehengas','kids','/images/kidsgirl.jpg',3),
('kids-indo-western','Kids Indo-Western','kids','/images/kids.jpg',4);

INSERT INTO public.collections (slug, name, tagline, image_url, sort_order) VALUES
('maharaja','Maharaja Collection','Heirloom craft for the men who lead the room','/images/hero.jpg',1),
('maharani','Maharani Collection','Regal silhouettes for the woman who commands the evening','/images/women.jpg',2),
('little-maharaja','Little Maharaja','Small prince, grand entrance','/images/kids.jpg',3),
('little-maharani','Little Maharani','Tiny royalty, timeless charm','/images/kidsgirl.jpg',4),
('wedding-royalty','Wedding Royalty','For the days that become legacy','/images/wedding.jpg',5),
('festive-royalty','Festive Royalty','Celebrate in colour, gold and light','/images/festive.jpg',6);

INSERT INTO public.products (slug,name,sku,description,gender,category_id,collection_id,price,mrp,fabric,occasion,care,colors,sizes,rating,review_count,is_featured,is_bestseller,is_new_arrival) VALUES
('royal-ivory-sherwani','Royal Ivory Sherwani','RT-M-1001','Hand-embroidered ivory silk sherwani with tonal zari threadwork, structured shoulders and a matching stole. Made for the grand entrance.','men',(SELECT id FROM public.categories WHERE slug='sherwanis'),(SELECT id FROM public.collections WHERE slug='maharaja'),42999,58999,'Raw Silk','Wedding','Dry clean only','{Ivory,Gold}','{S,M,L,XL,XXL}',4.8,42,true,true,true),
('maharaja-black-sherwani','Maharaja Black Sherwani','RT-M-1002','Midnight black sherwani with antique gold thread motifs and velvet trims. Quiet power, absolute presence.','men',(SELECT id FROM public.categories WHERE slug='sherwanis'),(SELECT id FROM public.collections WHERE slug='maharaja'),46999,62999,'Silk Blend','Wedding','Dry clean only','{Black,Emerald}','{S,M,L,XL,XXL}',4.9,31,true,true,false),
('regal-wine-kurta-set','Regal Wine Kurta Set','RT-M-1003','Deep wine silk kurta with fine hand embroidery at the placket, paired with churidar. Festive elegance, effortlessly worn.','men',(SELECT id FROM public.categories WHERE slug='kurta-sets'),(SELECT id FROM public.collections WHERE slug='festive-royalty'),12999,17999,'Art Silk','Festive','Dry clean recommended','{Wine,Ivory}','{S,M,L,XL,XXL}',4.6,58,false,true,true),
('imperial-bandhgala','Imperial Bandhgala','RT-M-1004','Tailored bandhgala in charcoal wool with cast gold buttons. The modern durbar suit.','men',(SELECT id FROM public.categories WHERE slug='bandhgala'),(SELECT id FROM public.collections WHERE slug='maharaja'),24999,32999,'Wool Blend','Reception','Dry clean only','{Black,Charcoal}','{S,M,L,XL,XXL}',4.7,24,true,false,true),
('royal-indo-western-set','Royal Indo-Western Set','RT-M-1005','Emerald draped indo-western with beaded yoke and asymmetric hem. Tradition, re-cut for today.','men',(SELECT id FROM public.categories WHERE slug='indo-western'),(SELECT id FROM public.collections WHERE slug='festive-royalty'),28999,38999,'Suiting Silk','Sangeet','Dry clean only','{Emerald,Black}','{S,M,L,XL}',4.5,19,false,false,true),
('maharani-emerald-lehenga','Maharani Emerald Lehenga','RT-W-2001','Emerald silk lehenga with dense gold zardozi, scalloped dupatta and hand-finished blouse. An heirloom in the making.','women',(SELECT id FROM public.categories WHERE slug='lehengas'),(SELECT id FROM public.collections WHERE slug='maharani'),68999,89999,'Silk','Wedding','Dry clean only','{Emerald,Burgundy}','{S,M,L,XL}',4.9,76,true,true,true),
('royal-burgundy-lehenga','Royal Burgundy Lehenga','RT-W-2002','Burgundy velvet lehenga with antique gold embroidery and a sheer embellished dupatta.','women',(SELECT id FROM public.categories WHERE slug='lehengas'),(SELECT id FROM public.collections WHERE slug='wedding-royalty'),74999,94999,'Velvet','Wedding','Dry clean only','{Burgundy,Ivory}','{S,M,L,XL}',4.8,54,true,true,false),
('ivory-embroidered-anarkali','Ivory Embroidered Anarkali','RT-W-2003','Floor-sweeping ivory anarkali with gold thread jaal and a tulle dupatta. Softly regal.','women',(SELECT id FROM public.categories WHERE slug='anarkali'),(SELECT id FROM public.collections WHERE slug='maharani'),32999,44999,'Georgette','Festive','Dry clean only','{Ivory,Gold}','{S,M,L,XL,XXL}',4.7,63,false,true,true),
('regal-silk-saree','Regal Silk Saree','RT-W-2004','Handloom banarasi silk saree in deep burgundy with a broad gold zari border and unstitched blouse piece.','women',(SELECT id FROM public.categories WHERE slug='sarees'),(SELECT id FROM public.collections WHERE slug='festive-royalty'),21999,28999,'Banarasi Silk','Festive','Dry clean only','{Burgundy,Emerald}','{S,M,L,XL,XXL}',4.6,88,true,false,false),
('royal-wedding-sharara','Royal Wedding Sharara','RT-W-2005','Ivory and gold sharara set with mirror-and-thread work and a heavily worked dupatta.','women',(SELECT id FROM public.categories WHERE slug='sharara'),(SELECT id FROM public.collections WHERE slug='wedding-royalty'),38999,52999,'Chinon Silk','Mehendi','Dry clean only','{Ivory,Emerald}','{S,M,L,XL}',4.5,29,false,false,true),
('little-maharaja-sherwani','Little Maharaja Sherwani','RT-K-3001','Maroon raw silk sherwani for young royals, with gold buttons and matching churidar.','kids',(SELECT id FROM public.categories WHERE slug='kids-sherwani'),(SELECT id FROM public.collections WHERE slug='little-maharaja'),8999,12999,'Raw Silk','Wedding','Gentle dry clean','{Maroon,Ivory}','{S,M,L,XL}',4.7,34,true,true,true),
('little-prince-kurta-set','Little Prince Kurta Set','RT-K-3002','Soft cotton-silk kurta set with a printed nehru jacket. Comfortable enough for a long celebration.','kids',(SELECT id FROM public.categories WHERE slug='kids-kurta-sets'),(SELECT id FROM public.collections WHERE slug='festive-royalty'),4999,6999,'Cotton Silk','Festive','Machine wash gentle','{Ivory,Emerald}','{S,M,L,XL}',4.4,41,false,true,false),
('little-maharani-lehenga','Little Maharani Lehenga','RT-K-3003','Ivory and gold lehenga with sequin work and a feather-light dupatta for the tiniest guest of honour.','kids',(SELECT id FROM public.categories WHERE slug='kids-lehengas'),(SELECT id FROM public.collections WHERE slug='little-maharani'),7499,10999,'Net','Wedding','Gentle dry clean','{Ivory,Wine}','{S,M,L,XL}',4.8,27,true,true,true),
('royal-kids-indo-western','Royal Kids Indo-Western','RT-K-3004','Emerald indo-western set with a draped panel and tailored trousers, cut for movement.','kids',(SELECT id FROM public.categories WHERE slug='kids-indo-western'),(SELECT id FROM public.collections WHERE slug='little-maharaja'),6499,8999,'Suiting Blend','Sangeet','Gentle dry clean','{Emerald,Black}','{S,M,L,XL}',4.3,16,false,false,true);

INSERT INTO public.product_images (product_id, url, alt, sort_order)
SELECT p.id, i.url, p.name, i.ord FROM public.products p
JOIN (VALUES
('royal-ivory-sherwani','/images/hero.jpg',0),('royal-ivory-sherwani','/images/wedding.jpg',1),
('maharaja-black-sherwani','/images/men.jpg',0),('maharaja-black-sherwani','/images/indowestern.jpg',1),
('regal-wine-kurta-set','/images/kurta.jpg',0),('regal-wine-kurta-set','/images/festive.jpg',1),
('imperial-bandhgala','/images/men.jpg',0),('imperial-bandhgala','/images/kurta.jpg',1),
('royal-indo-western-set','/images/indowestern.jpg',0),('royal-indo-western-set','/images/men.jpg',1),
('maharani-emerald-lehenga','/images/women.jpg',0),('maharani-emerald-lehenga','/images/festive.jpg',1),
('royal-burgundy-lehenga','/images/saree.jpg',0),('royal-burgundy-lehenga','/images/wedding.jpg',1),
('ivory-embroidered-anarkali','/images/anarkali.jpg',0),('ivory-embroidered-anarkali','/images/women.jpg',1),
('regal-silk-saree','/images/saree.jpg',0),('regal-silk-saree','/images/festive.jpg',1),
('royal-wedding-sharara','/images/anarkali.jpg',0),('royal-wedding-sharara','/images/wedding.jpg',1),
('little-maharaja-sherwani','/images/kids.jpg',0),('little-maharaja-sherwani','/images/kidsgirl.jpg',1),
('little-prince-kurta-set','/images/kids.jpg',0),
('little-maharani-lehenga','/images/kidsgirl.jpg',0),('little-maharani-lehenga','/images/kids.jpg',1),
('royal-kids-indo-western','/images/kids.jpg',0)
) AS i(slug,url,ord) ON i.slug = p.slug;

INSERT INTO public.product_variants (product_id, size, color, stock, sku)
SELECT p.id, s.size, c.color,
  CASE WHEN s.size IN ('M','L') THEN 8 WHEN s.size = 'XXL' THEN 2 ELSE 5 END,
  p.sku || '-' || s.size || '-' || upper(left(c.color,2))
FROM public.products p
CROSS JOIN LATERAL unnest(p.sizes) AS s(size)
CROSS JOIN LATERAL unnest(p.colors) AS c(color);

INSERT INTO public.banners (placement,title,subtitle,image_url,cta_label,cta_href,sort_order) VALUES
('hero','Dress Like Royalty.','Timeless Indian fashion crafted for the moments where you deserve to rule.','/images/hero.jpg','Shop Collection','/shop',1),
('offer','Wedding Season Preview','Up to 25% off on the Wedding Royalty edit',NULL,'Explore','/collections/wedding-royalty',1),
('offer','Free Royal Delivery','On every order above ₹4,999, across India',NULL,'Shop Now','/shop',2),
('offer','First Order Ritual','Use code ROYAL10 for 10% off your first entrance',NULL,'Apply Code','/shop',3),
('wedding','Wedding Royalty','Some entrances are remembered for a lifetime. Dress for that one.','/images/wedding.jpg','Shop Wedding','/collections/wedding-royalty',1),
('festive','Festive Royalty','Colour, gold and candlelight — the season of celebration begins.','/images/festive.jpg','Shop Festive','/collections/festive-royalty',1);

INSERT INTO public.coupons (code,discount_type,discount_value,min_order_amount,max_discount,expires_at,usage_limit,per_user_limit) VALUES
('ROYAL10','percent',10,4999,5000,now() + interval '180 days',1000,1),
('MAHARAJA15','percent',15,24999,10000,now() + interval '120 days',500,1),
('FESTIVE2000','fixed',2000,14999,NULL,now() + interval '90 days',300,1);

INSERT INTO public.reviews (product_id,author_name,rating,body,is_verified,is_approved)
SELECT p.id, r.author, r.rating, r.body, true, true FROM public.products p
JOIN (VALUES
('royal-ivory-sherwani','Aditya Rathore',5,'Wore this for my wedding in Udaipur. The fit and the embroidery were beyond anything I tried in stores.'),
('royal-ivory-sherwani','Karan Mehta',5,'Genuinely feels like a heirloom piece. Every guest asked where it was from.'),
('maharani-emerald-lehenga','Ananya Sharma',5,'The emerald is even richer in person. I felt like a queen the entire evening.'),
('maharani-emerald-lehenga','Ritika Sen',4,'Beautiful craftsmanship and the dupatta drape is perfect. Slightly heavy, as expected.'),
('regal-silk-saree','Meera Iyer',5,'Authentic banarasi weave with a stunning zari border. Worth every rupee.'),
('regal-wine-kurta-set','Vikram Nair',5,'Comfortable through a full night of celebration and still looked crisp in photos.'),
('little-maharaja-sherwani','Pooja Deshmukh',5,'My son refused to take it off. Soft lining and lovely detailing.'),
('royal-burgundy-lehenga','Simran Kaur',5,'The velvet quality is exceptional. This is couture-level finishing.')
) AS r(slug,author,rating,body) ON r.slug = p.slug;